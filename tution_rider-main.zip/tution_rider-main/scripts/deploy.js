#!/usr/bin/env node

/**
 * Deployment script for Tuition Rider
 *
 * This script handles the deployment process for the Tuition Rider application
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables
const isProd = process.env.NODE_ENV === 'production';
const envFile = isProd ? '.env.production' : '.env';
dotenv.config({ path: path.join(process.cwd(), envFile) });

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

// Log with colors and emojis
function log(message, type = 'info') {
  const emoji = {
    info: '📌',
    success: '✅',
    warning: '⚠️',
    error: '❌',
    step: '🔷'
  };
  
  const color = type === 'error' ? colors.red : 
                type === 'success' ? colors.green : 
                type === 'warning' ? colors.yellow :
                type === 'step' ? colors.blue : colors.cyan;
  
  console.log(`${color}${emoji[type]} ${message}${colors.reset}`);
}

function executeCommand(command, silent = false) {
  try {
    execSync(command, { stdio: silent ? 'ignore' : 'inherit' });
    return true;
  } catch (error) {
    log(`Error executing command: ${command}`, 'error');
    if (!silent) {
      log(error.message, 'error');
    }
    return false;
  }
}

async function deploy() {
  log('Starting deployment process...', 'step');
  
  // Check if we're in production mode
  if (isProd) {
    log('Deploying in PRODUCTION mode', 'warning');
  } else {
    log('Deploying in DEVELOPMENT mode', 'info');
  }

  // Check if we should skip database checks
  const skipDbCheck = process.argv.includes('--skip-db-check');

  // Ensure database is ready (if not skipping)
  if (!skipDbCheck) {
    log('Checking database connection...', 'step');
    if (!executeCommand('npx prisma db pull', true)) {
      log('Database connection failed. Please check your DATABASE_URL', 'warning');
      log('Continuing deployment without database verification', 'warning');
    } else {
      log('Database connection successful', 'success');
    }
  } else {
    log('Skipping database connection check (--skip-db-check flag provided)', 'info');
  }

  // Generate Prisma client
  log('Generating Prisma client...', 'step');
  if (!executeCommand('npx prisma generate', true)) {
    log('Failed to generate Prisma client, but continuing with deployment...', 'warning');
    log('This may cause issues if your application relies on Prisma', 'warning');
  } else {
    log('Prisma client generated successfully', 'success');
  }

  // Build the application
  log('Building the application...', 'step');
  if (!executeCommand('npm run build')) {
    log('Build failed. Please check the errors above', 'error');
    process.exit(1);
  }
  log('Build completed successfully', 'success');

  // Start the application
  log('Starting the application...', 'step');
  if (isProd) {
    // Check if PM2 is installed
    const hasPM2 = executeCommand('pm2 --version', true);
    
    if (hasPM2) {
      log('Using PM2 for production deployment', 'info');
      executeCommand('pm2 delete tuition-rider', true); // Delete if exists
      executeCommand('pm2 start npm --name "tuition-rider" -- start');
      executeCommand('pm2 save');
      log('Application deployed with PM2', 'success');
    } else {
      log('PM2 not found. Starting with standard npm start', 'warning');
      log('For production, we recommend installing PM2: npm install -g pm2', 'info');
      executeCommand('npm start');
    }
  } else {
    executeCommand('npm start');
  }
}

// Run the deployment process
deploy().catch(error => {
  log('Deployment failed:', 'error');
  log(error.message, 'error');
  process.exit(1);
});