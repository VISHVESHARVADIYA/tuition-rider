const fs = require('fs');
const path = require('path');

const fontsDir = path.resolve(process.cwd(), 'public', 'fonts');
if (!fs.existsSync(fontsDir)) {
  fs.mkdirSync(fontsDir, { recursive: true });
}

// Copy Inter font files if they don't exist
const interFonts = [
  'Inter-Regular.woff2',
  'Inter-Medium.woff2',
  'Inter-SemiBold.woff2',
  'Inter-Bold.woff2'
];

interFonts.forEach(font => {
  const sourcePath = path.resolve(process.cwd(), 'node_modules', '@fontsource', 'inter', 'files', font);
  const destPath = path.join(fontsDir, font);
  
  if (fs.existsSync(sourcePath) && !fs.existsSync(destPath)) {
    fs.copyFileSync(sourcePath, destPath);
    console.log(`Copied ${font}`);
  }
});

console.log('Font copying complete!');