const fs = require('fs');
const path = require('path');

const appDir = path.resolve(process.cwd(), 'app');
const routesToRemove = [
  'api/auth/callback',
  'api/auth/csrf',
  'api/auth/signin',
  'api/auth/signout',
  'api/auth/session',
  'api/auth/providers',
  'api/auth/error',
  'api/auth/verify-request',
  'api/auth/new-user'
];

routesToRemove.forEach(route => {
  const routePath = path.join(appDir, route);
  if (fs.existsSync(routePath)) {
    fs.rmSync(routePath, { recursive: true, force: true });
    console.log(`Removed ${route}`);
  }
}); 