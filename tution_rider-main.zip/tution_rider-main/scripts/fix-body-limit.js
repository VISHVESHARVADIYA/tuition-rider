// Script to fix the body size limit issue
const fs = require('fs');
const path = require('path');

console.log('Fixing body size limit issue in Next.js config...');

// Path to Next.js config file
const configPath = path.resolve(process.cwd(), 'next.config.js');

// Check if the file exists
if (!fs.existsSync(configPath)) {
  console.error('Error: next.config.js file not found!');
  process.exit(1);
}

// Read the config file
let configContent = fs.readFileSync(configPath, 'utf8');

// Check if the experimental section already exists
if (configContent.includes('experimental:')) {
  // Check if serverActions already exists
  if (configContent.includes('serverActions:')) {
    // Check if bodySizeLimit already exists
    if (configContent.includes('bodySizeLimit:')) {
      // Update the body size limit
      configContent = configContent.replace(
        /bodySizeLimit:\s*['"][\w\d]+['"]/,
        "bodySizeLimit: '4mb'"
      );
      console.log('Updated existing body size limit to 4MB');
    } else {
      // Add body size limit to existing serverActions
      configContent = configContent.replace(
        /serverActions:\s*{/,
        "serverActions: {\n      bodySizeLimit: '4mb',"
      );
      console.log('Added body size limit to existing serverActions');
    }
  } else {
    // Add serverActions to existing experimental section
    configContent = configContent.replace(
      /experimental:\s*{/,
      "experimental: {\n    serverActions: {\n      bodySizeLimit: '4mb'\n    },"
    );
    console.log('Added serverActions with body size limit to existing experimental section');
  }
} else {
  // Add complete experimental section before webpack
  configContent = configContent.replace(
    /webpack:\s*\(/,
    "experimental: {\n    serverActions: {\n      bodySizeLimit: '4mb'\n    }\n  },\n\n  webpack: ("
  );
  console.log('Added complete experimental section with serverActions and body size limit');
}

// Write the updated config file
fs.writeFileSync(configPath, configContent, 'utf8');

console.log('Successfully fixed body size limit issue in Next.js config');
console.log('Restart your Next.js server for the changes to take effect'); 