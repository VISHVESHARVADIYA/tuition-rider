// Mock implementation of next-auth
const mockSession = {
  data: { 
    session: null, 
    user: null 
  },
  status: 'unauthenticated'
};

// Mock the useSession hook
export function useSession() {
  return mockSession;
}

// Mock the signIn function
export function signIn() {
  return Promise.resolve({ ok: true, error: null });
}

// Mock the signOut function
export function signOut() {
  return Promise.resolve({ ok: true });
}

// Mock the getServerSession function
export function getServerSession() {
  return Promise.resolve(null);
}

// Mock SessionProvider component
export function SessionProvider({ children }) {
  return children;
}

// Default export for Next Auth
export default {
  useSession,
  signIn,
  signOut,
  getServerSession,
  SessionProvider
};

// Mock the auth function
export function auth() {
  return { auth: null };
}

// Common Next Auth exports
export const getServerAuthSession = getServerSession;
export const authOptions = {};
export const handlers = { GET: () => {}, POST: () => {} }; 