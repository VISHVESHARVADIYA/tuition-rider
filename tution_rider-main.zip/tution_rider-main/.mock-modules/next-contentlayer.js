// Mock implementation for next-contentlayer/hooks
export function useMDXComponent(code) {
  // Return a function that renders children as-is
  return function MDXComponent({ children }) {
    return children || null;
  };
}

// Mock for allDocuments
export const allDocuments = [];

// Mock for allPosts
export const allPosts = [];

// Mock for other common exports
export const allPages = [];

export default {
  useMDXComponent,
  allDocuments,
  allPosts,
  allPages
}; 