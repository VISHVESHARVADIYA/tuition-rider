// Mock for Sentry implementations
const noOp = () => {};

// Common Sentry functions
const captureException = noOp;
const captureMessage = noOp;
const captureEvent = noOp;
const startTransaction = () => ({ finish: noOp });
const configureScope = noOp;
const withScope = (callback) => callback({ setTag: noOp, setExtra: noOp });

// Init methods
const init = noOp;
const flush = () => Promise.resolve(true);

// Node exports
export const NodeClient = class {
  constructor() {}
  captureException = captureException;
  captureMessage = captureMessage;
  captureEvent = captureEvent;
};

// Browser exports
export const BrowserClient = NodeClient;

// Next.js specific
export const withSentry = (app) => app;
export const withSentryConfig = (config) => config;

// General exports
export {
  init,
  captureException,
  captureMessage,
  captureEvent,
  startTransaction,
  configureScope,
  withScope,
  flush
};

// Default export
export default {
  init,
  captureException,
  captureMessage,
  captureEvent,
  startTransaction,
  configureScope,
  withScope,
  flush,
  Integrations: { Http: class {} },
  Transports: { HTTPSTransport: class {} }
}; 