// Using CSS variables for fonts to be compatible with both Babel and SWC
// This is a fallback approach that doesn't use next/font directly

// Define CSS variables that will be used in the global CSS
export const fontVariables = {
  sans: 'var(--font-sans)',
  urban: 'var(--font-urban)',
  heading: 'var(--font-heading)',
  geist: 'var(--font-geist)',
};

// Export empty objects with the same structure as the original fonts
// to maintain compatibility with existing code
export const fontSans = { variable: '--font-sans' };
export const fontUrban = { variable: '--font-urban' };
export const fontHeading = { variable: '--font-heading' };
export const fontGeist = { variable: '--font-geist' };
