import { UserRole } from "@prisma/client"

export interface SidebarNavItem {
  title: string
  items: {
    href: string
    icon: string
    title: string
    authorizeOnly?: UserRole
  }[]
}

export interface NavItem {
  title: string;
  href?: string;
  external?: boolean;
  icon?: any;
  label?: string;
  description?: string;
}

export interface MarketingConfig {
  mainNav: {
    title: string
    href: string
    items?: {
      title: string
      href: string
    }[]
  }[]
  protectedNav: {
    admin: { title: string; href: string }[]
    tutor: { title: string; href: string }[]
    student: { title: string; href: string }[]
    user: { title: string; href: string }[]
  }
} 