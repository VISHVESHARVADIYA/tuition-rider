export interface TableOfContents {
  text: string;
  level: number;
  id: string;
}

export interface TocItem {
  title: string;
  url: string;
  items?: TocItem[];
}

export interface TocItems {
  items?: TocItem[];
} 