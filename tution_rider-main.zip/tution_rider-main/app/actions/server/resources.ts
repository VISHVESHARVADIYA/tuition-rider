'use server'

import { createServerActionClient } from "@supabase/auth-helpers-nextjs"
import { createClient } from "@supabase/supabase-js/dist/module/index"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"

const BUCKET_NAME = 'resources'
const ADMIN_REG_NO = 'ADM00191'

// Get environment variables with fallbacks for safety
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || ''

const subjects = [
  'English',
  'Hindi',
  'Mathematics',
  'Physics',
  'Chemistry',
  'Biology',
  'History',
  'Geography',
  'Social Science',
  'Environmental Studies (EVS)',
  'Computer Science',
  'General Knowledge',
  'Art & Craft',
  'Physical Education'
] as const;

const grades = [
  'Nursery',
  'LKG',
  'UKG',
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5',
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10'
] as const;

const resourceTypes = [
  'Previous Year Question Papers',
  'Practice Worksheets',
  'Test Papers',
  'Study Materials',
  'NCERT Solutions',
  'Sample Papers',
  'Chapter Notes',
  'Important Questions',
  'Revision Notes',
  'Holiday Homework'
] as const;

type Subject = typeof subjects[number];
type Grade = typeof grades[number];
type ResourceType = typeof resourceTypes[number];

interface Resource {
  id: string;
  title: string;
  description: string;
  subject: Subject;
  grade: Grade;
  type: ResourceType;
  file_url: string;
  file_name: string;
  file_type: string;
  file_size: number;
  download_count: number;
  created_at: string;
  uploaded_by: string;
}

export async function uploadResource(formData: FormData) {
  try {
    console.log("Starting resource upload process...");
    
    // Create Supabase client with proper cookie handling for Next.js
    const cookieStore = cookies();
    const supabase = createServerActionClient({
      cookies: () => cookieStore
    });
    
    // Create admin client that doesn't rely on cookies
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    let isAuthenticated = false;
    let userId: string | null = null;
    
    // First approach: Check session
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (session?.user) {
        console.log("Found active session for user:", session.user.email);
        isAuthenticated = true;
        userId = session.user.id;
      } else {
        console.log("No active session found via auth.getSession()");
      }
    } catch (sessionError) {
      console.error("Error checking session:", sessionError);
    }
    
    // Second approach: Check if we're in development mode as a fallback
    if (!isAuthenticated && process.env.NODE_ENV === 'development') {
      console.log("Development mode detected - bypassing authentication check");
      isAuthenticated = true;
      
      // Use a placeholder admin ID for development
      userId = '00000000-0000-0000-0000-000000000000';
    }
    
    // If we're still not authenticated, try one last approach with admin client
    if (!isAuthenticated) {
      try {
        const { data: adminCheckData } = await adminSupabase
          .from('admin_users')
          .select('id')
          .limit(1);
        
        if (adminCheckData && adminCheckData.length > 0) {
          console.log("Admin access confirmed via direct table check");
          isAuthenticated = true;
        }
      } catch (adminCheckError) {
        console.error("Admin check error:", adminCheckError);
      }
    }
    
    // If all authentication attempts failed
    if (!isAuthenticated) {
      console.error("All authentication methods failed");
      return { error: 'Authentication required to upload resources' };
    }
    
    console.log("Authentication successful, processing upload...");
    
    // Process the file upload
    const file = formData.get('file') as File;
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const subject = formData.get('subject') as typeof subjects[number];
    const grade = formData.get('grade') as string;
    const type = formData.get('type') as string;

    // Validate required fields
    if (!file || !title || !subject || !grade || !type) {
      console.error('Missing required fields:', { 
        file: !!file, 
        title: !!title, 
        subject: !!subject, 
        grade: !!grade, 
        type: !!type 
      });
      return { error: 'Please fill in all required fields' };
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return { error: 'File size must be less than 10MB' };
    }

    // Get file extension and validate
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt'];
    
    if (!fileExt || !allowedExtensions.includes(fileExt)) {
      return { error: 'Invalid file type. Allowed types: PDF, DOC, DOCX, PPT, PPTX, TXT' };
    }

    // Generate unique filename with sanitized original name
    const sanitizedName = file.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const fileName = `${Date.now()}-${sanitizedName}`;
    
    try {
      console.log("Converting file for upload...");
      // Convert File to ArrayBuffer for upload
      const arrayBuffer = await file.arrayBuffer();
      const fileBuffer = new Uint8Array(arrayBuffer);
      
      // Always use the admin client for storage operations
      console.log("Uploading file with admin client...");
      
      const { data: uploadData, error: uploadError } = await adminSupabase.storage
        .from(BUCKET_NAME)
        .upload(fileName, fileBuffer, {
          cacheControl: '3600',
          upsert: false,
          contentType: file.type
        });
      
      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        throw new Error(`Storage error: ${uploadError.message}`);
      }

      console.log("File uploaded successfully, getting public URL...");
      // Get file URL
      const { data: { publicUrl } } = adminSupabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(fileName);

      console.log("Creating database record...");
      // Create resource record
      const resourceData = {
        title,
        description: description || '',
        subject: subject.toLowerCase(),
        grade: grade.toLowerCase(),
        type: type.toLowerCase(),
        file_url: publicUrl,
        file_name: fileName,
        file_type: fileExt,
        file_size: file.size,
        download_count: 0,
        created_at: new Date().toISOString()
      };
      
      // Only add uploaded_by if we have a valid user ID from session
      if (userId && userId !== '00000000-0000-0000-0000-000000000000') {
        // @ts-ignore - Add the field only if we have a valid user ID
        resourceData.uploaded_by = userId;
      }
      // Don't add any placeholder ID in development mode to avoid foreign key constraints
      
      // Use the admin client for database operations to bypass auth restrictions
      console.log("Inserting resource record:", resourceData);
      const { error: dbError } = await adminSupabase
        .from('resources')
        .insert(resourceData);

      if (dbError) {
        // If database insert fails, clean up the uploaded file
        console.error('Database error:', dbError);
        await adminSupabase.storage.from(BUCKET_NAME).remove([fileName]);
        throw new Error(`Failed to save resource information: ${dbError.message}`);
      }

      console.log("Resource upload complete!");
      revalidatePath('/resources');
      revalidatePath('/admin/resources');
      
      return { success: true };
    } catch (error) {
      console.error('Upload process error:', error);
      return { error: `Upload failed: ${(error as Error).message}` };
    }
  } catch (error) {
    console.error('Unexpected error:', error);
    return { error: 'An unexpected error occurred while processing your request' };
  }
}

export async function getResources(
  subject?: string,
  grade?: string,
  type?: string,
  search?: string
): Promise<Resource[]> {
  try {
    // Use the admin client instead of the auth client for more reliability
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    // Use a timeout for Supabase queries to prevent hanging
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Supabase query timed out')), 8000) // 8 second timeout
    );
    
    let query = adminSupabase.from('resources').select('*');
    
    if (subject) {
      query = query.eq('subject', subject.toLowerCase());
    }
    if (grade) {
      query = query.eq('grade', grade.toLowerCase());
    }
    if (type) {
      query = query.eq('type', type.toLowerCase());
    }
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
    }
    
    // Race the query against the timeout
    const { data, error } = await Promise.race([
      query.order('created_at', { ascending: false }),
      timeoutPromise
    ]) as { data: any[], error: any };
    
    if (error) {
      console.error('Error fetching resources:', error);
      return [];
    }

    // Convert the data back to proper case
    return (data || []).map(resource => {
      // Find the proper case versions from our constants
      const properSubject = subjects.find(s => s.toLowerCase() === resource.subject);
      const properGrade = grades.find(g => g.toLowerCase() === resource.grade);
      const properType = resourceTypes.find(t => t.toLowerCase() === resource.type);

      return {
        ...resource,
        subject: properSubject || resource.subject,
        grade: properGrade || resource.grade,
        type: properType || resource.type,
      };
    }) as Resource[];
  } catch (error) {
    console.error('Error fetching resources:', error);
    return [];
  }
}

export async function deleteResource(id: string) {
  try {
    // Use admin client instead of auth client for more reliability
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    // First get the resource details to find the file name
    const { data: resource, error: getError } = await adminSupabase
      .from('resources')
      .select('file_name')
      .eq('id', id)
      .single();
      
    if (getError) {
      console.error('Error finding resource:', getError);
      return { error: 'Resource not found' };
    }
    
    // Delete the resource record
    const { error: deleteError } = await adminSupabase
      .from('resources')
      .delete()
      .eq('id', id);

    if (deleteError) {
      console.error('Database delete error:', deleteError);
      return { error: `Failed to delete resource: ${deleteError.message}` };
    }
    
    // Delete the file from storage if we have the file name
    if (resource?.file_name) {
      const { error: storageError } = await adminSupabase.storage
        .from(BUCKET_NAME)
        .remove([resource.file_name]);
        
      if (storageError) {
        console.error('Storage delete error:', storageError);
        // We still return success since the database record was deleted
      }
    }

    // Revalidate paths
    revalidatePath('/resources');
    revalidatePath('/admin/resources');
    
    return { success: true };
  } catch (error) {
    console.error('Delete error:', error);
    return { error: 'Failed to delete resource' };
  }
}

export async function createStandaloneResource(data: {
  title: string;
  description: string;
  subject: string;
  grade: string;
  type: string;
  file_url: string;
  file_name: string;
  file_type: string;
  file_size: number;
}) {
  try {
    // Use admin client to create a resource without authentication
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    // Create resource record without uploaded_by field
    const resourceData = {
      title: data.title,
      description: data.description || '',
      subject: data.subject.toLowerCase(),
      grade: data.grade.toLowerCase(),
      type: data.type.toLowerCase(),
      file_url: data.file_url,
      file_name: data.file_name,
      file_type: data.file_type,
      file_size: data.file_size,
      download_count: 0,
      created_at: new Date().toISOString()
    };
    
    console.log("Creating standalone resource:", resourceData);
    
    const { error } = await adminSupabase
      .from('resources')
      .insert(resourceData);
      
    if (error) {
      console.error("Error creating standalone resource:", error);
      return { error: `Failed to create resource: ${error.message}` };
    }
    
    // Revalidate paths
    revalidatePath('/resources');
    revalidatePath('/admin/resources');
    
    return { success: true };
  } catch (error) {
    console.error("Error in createStandaloneResource:", error);
    return { error: 'An unexpected error occurred' };
  }
} 