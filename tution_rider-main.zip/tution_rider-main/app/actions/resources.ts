import { createServerActionClient } from "@supabase/auth-helpers-nextjs"
import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"

// Get environment variables
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
const BUCKET_NAME = 'resources';

export async function uploadResource(formData: FormData) {
  try {
    // Create Supabase client with proper cookie handling
    const cookieStore = cookies();
    const supabase = createServerActionClient({
      cookies: () => cookieStore
    });
    
    // Create a client that doesn't depend on cookie auth
    const adminClient = createClient(
      SUPABASE_URL,
      SUPABASE_ANON_KEY
    );
    
    const file = formData.get('file') as File
    const title = formData.get('title') as string
    const description = formData.get('description') as string
    const subject = formData.get('subject') as string
    const grade = formData.get('grade') as string
    const type = formData.get('type') as string

    if (!file || !title || !subject || !grade || !type) {
      return { error: 'Missing required fields' }
    }

    // Upload file to storage
    const fileExt = file.name.split('.').pop()
    const fileName = `${Date.now()}.${fileExt}`
    
    const { data: uploadData, error: uploadError } = await adminClient.storage
      .from(BUCKET_NAME)
      .upload(fileName, file)

    if (uploadError) throw uploadError

    // Get file URL
    const { data: { publicUrl } } = adminClient.storage
      .from(BUCKET_NAME)
      .getPublicUrl(fileName)

    // Create resource record
    const { error: dbError } = await adminClient
      .from('resources')
      .insert({ 
        title,
        description,
        subject,
        grade,
        type,
        file_url: publicUrl,
      });

    if (dbError) throw dbError

    revalidatePath('/resources')
    revalidatePath('/admin/resources')
    
    return { success: true }
  } catch (error) {
    console.error('Upload error:', error)
    return { error: 'Failed to upload resource' }
  }
}

export async function getResources(subject?: string, grade?: string, search?: string) {
  try {
    // Create a client that doesn't depend on cookie auth
    const adminClient = createClient(
      SUPABASE_URL,
      SUPABASE_ANON_KEY
    );
    
    let query = adminClient.from('resources').select('*')
    
    if (subject) {
      query = query.eq('subject', subject)
    }
    if (grade) {
      query = query.eq('grade', grade)
    }
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`)
    }
    
    const { data, error } = await query.order('created_at', { ascending: false })
    
    if (error) {
      console.error('Error fetching resources:', error)
      return []
    }
    
    return data
  } catch (error) {
    console.error('Error fetching resources:', error)
    return []
  }
}

export async function deleteResource(id: string) {
  try {
    // Create a client that doesn't depend on cookie auth
    const adminClient = createClient(
      SUPABASE_URL,
      SUPABASE_ANON_KEY
    );
    
    // First get resource details to find file name
    const { data: resource } = await adminClient
      .from('resources')
      .select('file_name')
      .eq('id', id)
      .single();
    
    // Delete the resource record
    const { error } = await adminClient
      .from('resources')
      .delete()
      .eq('id', id)

    if (error) throw error
    
    // Delete file from storage if we have the filename
    if (resource?.file_name) {
      await adminClient.storage
        .from(BUCKET_NAME)
        .remove([resource.file_name]);
    }

    revalidatePath('/resources')
    revalidatePath('/admin/resources')
    
    return { success: true }
  } catch (error) {
    console.error('Delete error:', error)
    return { error: 'Failed to delete resource' }
  }
} 