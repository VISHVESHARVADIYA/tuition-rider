// Client-side version of the contact form submission
// Used as a fallback in static export mode

import { z } from "zod";

// Form validation schema
export const ContactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

// Type for the form input data
export type ContactFormValues = z.infer<typeof ContactFormSchema>;

// Client-side action
export async function contactFormAction(data: ContactFormValues) {
  // In a static export, we'll redirect form submissions to a third-party service
  // For example, this could be a Netlify form, Formspree, or any API endpoint

  try {
    // Demo implementation using a public API endpoint
    // In production, replace with your actual form handling service
    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        access_key: "YOUR_ACCESS_KEY", // Replace with your access key
        subject: "New Contact Form Submission",
        from_name: "Tuition Rider Contact Form",
        ...data,
      }),
    });

    const result = await response.json();

    if (result.success) {
      return { success: true, message: "Message sent successfully!" };
    } else {
      return { 
        success: false, 
        message: "Failed to send message. Please try again." 
      };
    }
  } catch (error) {
    console.error("Error submitting form:", error);
    return { 
      success: false, 
      message: "Something went wrong. Please try again later."
    };
  }
} 