// Client-side version of the resources actions
// Used as a fallback in static export mode

import { z } from "zod";

// Resource schema
export const ResourceSchema = z.object({
  title: z.string().min(2, "Title must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  subject: z.string().min(1, "Subject is required"),
  grade: z.string().min(1, "Grade is required"),
  type: z.string().min(1, "Type is required"),
  // Optional fields for any additional information
  tags: z.array(z.string()).optional(),
  author: z.string().optional(),
});

// Type for resource data
export type ResourceValues = z.infer<typeof ResourceSchema>;

// Client-side action to fetch resources
export async function getResources() {
  // In static export, we would typically fetch from a JSON file or external API
  try {
    // Example: Fetch from a static JSON file that would be included in the build
    const response = await fetch('/data/resources.json');
    if (!response.ok) {
      throw new Error('Failed to fetch resources');
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching resources:", error);
    // Return empty array as fallback
    return { resources: [] };
  }
}

// Client-side action to get a single resource
export async function getResource(id: string) {
  try {
    // Example: Fetch from a static JSON file
    const response = await fetch('/data/resources.json');
    if (!response.ok) {
      throw new Error('Failed to fetch resources');
    }
    
    const data = await response.json();
    // Find the resource with the matching ID
    const resource = data.resources.find((r: any) => r.id === id);
    
    if (!resource) {
      throw new Error('Resource not found');
    }
    
    return { resource };
  } catch (error) {
    console.error(`Error fetching resource ${id}:`, error);
    return { resource: null, error: 'Resource not found' };
  }
} 