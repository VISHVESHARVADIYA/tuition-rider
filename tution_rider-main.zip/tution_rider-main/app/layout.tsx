import "@/styles/globals.css";
import { fontSans, fontVariables } from "@/assets/fonts";
import { Toaster } from "@/app/components/ui/sonner";
import { cn, constructMetadata } from "./lib/utils";
import { Analytics } from "@/app/components/analytics";
import ClientStructuredData from "./components/client-structured-data.js";
import HeadMeta from "./components/head-meta";

export const metadata = constructMetadata();

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn(
        "min-h-screen bg-background font-sans antialiased",
        fontSans.variable,
        fontVariables
      )}>
        {/* Client components for head metadata and structured data */}
        <HeadMeta />
        <ClientStructuredData />
        {children}
        <Toaster />
        <Analytics />
      </body>
    </html>
  );
}
