import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

// Change from static to dynamic to enable proper session handling
export const dynamic = 'force-dynamic';

// This is a simplified login API that works with cookie-based authentication
export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    // Validate input
    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // Create Supabase client with proper cookie handling
    const cookieStore = cookies();
    const supabase = createRouteHandlerClient({ 
      cookies: () => cookieStore 
    });

    // Attempt to sign in with Supabase
    const { data: { session }, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (signInError || !session) {
      return NextResponse.json(
        { error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();

    if (profileError || !profile) {
      await supabase.auth.signOut();
      return NextResponse.json(
        { error: 'Failed to get user profile' },
        { status: 500 }
      );
    }

    // Update login info
    await supabase
      .from('profiles')
      .update({
        last_login: new Date().toISOString(),
        login_count: (profile.login_count || 0) + 1
      })
      .eq('id', profile.id);

    // Create response
    const response = NextResponse.json({
      message: 'Login successful',
      user: {
        id: profile.id,
        email: profile.email,
        fullName: profile.full_name,
        role: profile.role
      },
      redirectUrl: profile.role === 'ADMIN' ? '/admin' : '/'
    });

    // Set cookies
    response.cookies.set('user-role', profile.role, {
      httpOnly: false,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: '/'
    });

    response.cookies.set('user-session', JSON.stringify({
      id: profile.id,
      email: profile.email,
      fullName: profile.full_name,
      role: profile.role
    }), {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: '/'
    });

    if (profile.role === 'ADMIN') {
      response.cookies.set('admin-auth', 'true', {
        httpOnly: false,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 7, // 1 week
        path: '/'
      });
    }

    return response;

  } catch (error: unknown) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'An unexpected error occurred. Please try again later.' },
      { status: 500 }
    );
  }
}
