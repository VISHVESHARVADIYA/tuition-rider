import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

// Add experimental tag for cookies compatibility
export const runtime = 'edge';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const { regNo, password } = await request.json();
    
    // Input validation
    if (!regNo || !password) {
      console.log('Admin login attempt for registration number:', regNo);
      console.log('Missing credentials');
      return NextResponse.json(
        { error: 'Registration number and password are required' },
        { status: 400 }
      );
    }

    console.log('Admin login attempt for registration number:', regNo);
    
    // Check for hardcoded admin credentials first
    const ADMIN_REG_NO = 'ADM00191';
    const ADMIN_PASSWORD = 'Admin91912';
    
    if (regNo === ADMIN_REG_NO && password === ADMIN_PASSWORD) {
      console.log('Using hardcoded admin credentials');
      
      // Create Supabase client
      const cookieStore = cookies();
      const supabase = createRouteHandlerClient(
        { cookies: () => cookieStore },
        {
          supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL,
          supabaseKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
        }
      );
      
      // Get the admin user by email (first try to find existing admin)
      const { data: adminProfiles } = await supabase
        .from('profiles')
        .select('email, id')
        .eq('role', 'ADMIN');
      
      let adminEmail = 'admin@tuitionrider.com'; // Default admin email
      
      if (adminProfiles && adminProfiles.length > 0) {
        // Use the first admin's email
        adminEmail = adminProfiles[0].email;
        console.log('Using existing admin email:', adminEmail);
      }
      
      // Create a response to set cookies
      const response = NextResponse.json({ success: true });
      
      // Set the user role as admin in cookies for easier access
      response.cookies.set('user-role', 'ADMIN', { 
        path: '/',
        maxAge: 60 * 60 * 24 * 7, // 1 week
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production' 
      });
      
      // Set auth token in cookies (even without a real token, since we're using hardcoded)
      response.cookies.set('auth-token', 'admin-hardcoded-token', {
        path: '/',
        maxAge: 60 * 60 * 24 * 7, // 1 week
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production'
      });
      
      console.log('Admin login successful with hardcoded credentials');
      return response;
    }
    
    // Continue with normal authentication flow (check in database)
    // Create Supabase client with the updated approach for Next.js 14
    const cookieStore = cookies();
    const supabase = createRouteHandlerClient(
      { cookies: () => cookieStore },
      {
        supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL,
        supabaseKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      }
    );
    
    // Log all available profiles for debugging
    const { data: allProfiles } = await supabase
      .from('profiles')
      .select('id, email, role, registration_number');
    
    console.log('All profiles from database:', allProfiles);
    
    // Get admin user with this registration number
    const { data: adminProfile, error: lookupError } = await supabase
      .from('profiles')
      .select('id, email, role')
      .eq('registration_number', regNo)
      .eq('role', 'ADMIN')
      .single();
    
    // Verify the profile exists and is an admin
    if (lookupError || !adminProfile) {
      console.log('Admin not found with registration number:', regNo);
      return NextResponse.json(
        { error: 'Invalid registration number or password' },
        { status: 401 }
      );
    }
    
    console.log('Found admin with email:', adminProfile.email);
    
    // Sign in with the associated email and provided password
    const { data, error } = await supabase.auth.signInWithPassword({
      email: adminProfile.email,
      password,
    });
    
    if (error) {
      console.log('Admin auth error:', error.message);
      return NextResponse.json(
        { error: 'Invalid password' },
        { status: 401 }
      );
    }
    
    // Create a response to set cookies
    const response = NextResponse.json({ success: true });
    
    // Set the user role as admin in cookies for easier access
    response.cookies.set('user-role', 'ADMIN', { 
      path: '/',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production' 
    });
    
    // Set auth token in cookies
    response.cookies.set('auth-token', data.session?.access_token || '', {
      path: '/',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production'
    });
    
    console.log('Admin login successful for:', regNo);
    return response;
  } catch (error: any) {
    console.error('Admin login server error:', error);
    return NextResponse.json(
      { error: 'Server error during authentication' },
      { status: 500 }
    );
  }
}
