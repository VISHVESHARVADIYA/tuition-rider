// This file is used to generate static params for the [id] route
// It's separated to ensure it's properly recognized by Next.js

export function generateStaticParams() {
  // Return an empty array for static export
  // In a real app, you might want to fetch actual resource IDs here
  return [];
}