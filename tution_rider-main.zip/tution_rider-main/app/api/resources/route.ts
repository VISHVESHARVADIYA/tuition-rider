import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { createClient } from '@supabase/supabase-js/dist/module/index';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import type { Database } from '@/app/lib/database.types';

// Set dynamic mode to ensure Supabase connections work properly
export const dynamic = 'force-dynamic';
export const revalidate = 0;

// Get environment variables with fallbacks
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

// Mock resources data for fallback when database access fails
const mockResources = [
  {
    id: '1',
    title: 'Mathematics Formulas',
    description: 'Key formulas for all units',
    subject: 'Mathematics',
    grade: 'Class 10',
    type: 'Study Materials',
    file_url: 'https://example.com/math-formulas.pdf',
    file_name: 'math-formulas.pdf',
    file_type: 'application/pdf',
    file_size: 1024576, // 1MB in bytes
    uploaded_by: '00000000-0000-0000-0000-000000000001',
    download_count: 145,
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    title: 'Physics Sample Papers',
    description: 'Practice papers for final exams',
    subject: 'Physics',
    grade: 'Class 9',
    type: 'Sample Papers',
    file_url: 'https://example.com/physics-papers.pdf',
    file_name: 'physics-papers.pdf',
    file_type: 'application/pdf',
    file_size: 2048576, // 2MB in bytes
    uploaded_by: '00000000-0000-0000-0000-000000000001',
    download_count: 89,
    created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '3',
    title: 'English Grammar Worksheets',
    description: 'Practice worksheets for grammar',
    subject: 'English',
    grade: 'Class 8',
    type: 'Practice Worksheets',
    file_url: 'https://example.com/english-worksheets.pdf',
    file_name: 'english-worksheets.pdf',
    file_type: 'application/pdf',
    file_size: 1548576, // 1.5MB in bytes
    uploaded_by: '00000000-0000-0000-0000-000000000002',
    download_count: 120,
    created_at: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '4',
    title: 'Chemistry Revision Notes',
    description: 'Complete revision notes with diagrams',
    subject: 'Chemistry',
    grade: 'Class 11',
    type: 'Study Materials',
    file_url: 'https://example.com/chemistry-notes.pdf',
    file_name: 'chemistry-notes.pdf',
    file_type: 'application/pdf',
    file_size: 3145728, // 3MB in bytes
    uploaded_by: '00000000-0000-0000-0000-000000000002',
    download_count: 78,
    created_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '5',
    title: 'Biology Practice Questions',
    description: 'Multiple choice and short answer questions',
    subject: 'Biology',
    grade: 'Class 12',
    type: 'Practice Worksheets',
    file_url: 'https://example.com/biology-questions.pdf',
    file_name: 'biology-questions.pdf',
    file_type: 'application/pdf',
    file_size: 2621440, // 2.5MB in bytes
    uploaded_by: '00000000-0000-0000-0000-000000000001',
    download_count: 94,
    created_at: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString()
  }
];

export async function GET(request: Request) {
  try {
    // First handle Vercel serverless environments
    if (process.env.VERCEL || process.env.VERCEL_ENV) {
      console.log('Resources API running in Vercel environment - ensuring quick response');
    }

    // Get the request URL to extract filter parameters
    const { searchParams } = new URL(request.url);
    const subject = searchParams.get('subject');
    const grade = searchParams.get('grade');
    const type = searchParams.get('type');
    const search = searchParams.get('search');
    const isAdmin = searchParams.get('admin') === 'true' || request.headers.get('x-admin-access') === 'true';
    
    // Allow public access for the marketing resources page
    const isPublicRequest = searchParams.has('public') || 
                            request.headers.get('x-public-resource') === 'true';
    
    // Initialize auth variables
    let validAuth = false;
    let userId = null;
    
    // For public requests, continue with database fetch but don't require auth
    if (isPublicRequest) {
      console.log('Public resources request - attempting to fetch actual resources');
      validAuth = true; // Skip auth checks for public access
      
      // We'll fetch the real data below, and only use demo data as fallback if that fails
    }

    // Create admin Supabase client with service role key for direct database access
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    // For auth check, still use the cookie-based client
    const cookieStore = cookies();
    const supabase = createRouteHandlerClient<Database>({
      cookies: () => cookieStore
    });
    
    // Check auth methods - both cookie-based and bearer token
    const authHeader = request.headers.get('authorization');
    
    // First check for an auth header (Bearer token)
    if (authHeader?.startsWith('Bearer ')) {
      try {
        const token = authHeader.split(' ')[1];
        const { data: { user }, error } = await supabase.auth.getUser(token);
        
        if (!error && user) {
          console.log('Valid Bearer token authentication');
          validAuth = true;
          userId = user.id;
        } else {
          console.log('Invalid bearer token:', error?.message);
        }
      } catch (tokenError) {
        console.log('Error validating bearer token', tokenError);
      }
    }
    
    // If no valid token auth, try cookie-based auth
    if (!validAuth) {
      try {
        // Check for a valid session from cookies
        console.log('Checking cookie-based authentication');
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.log('Session error:', sessionError.message);
        } else if (session) {
          console.log('Valid cookie authentication found');
          validAuth = true;
          userId = session.user.id;
        } else {
          console.log('No valid session found in cookies');
        }
      } catch (cookieError) {
        console.log('Error checking cookie auth:', cookieError);
      }
    }
    
    // Always allow admin access in development mode or when admin flag is set
    if (!validAuth && (process.env.NODE_ENV === 'development' || isAdmin)) {
      console.log('Development or admin mode detected, allowing access');
      validAuth = true;
    }
    
    // If no authentication, return a 401 in development, or demo data in production
    if (!validAuth) {
      console.log('No valid authentication found');
      
      if (process.env.NODE_ENV === 'production') {
        console.log('Production mode - returning demo data for unauthenticated user');
        return NextResponse.json({
          resources: mockResources,
          demo: true,
          message: 'Using demo data - authentication required for real data'
        });
      } else {
        return NextResponse.json(
          { error: 'Authentication required', status: 401 },
          { status: 401 }
        );
      }
    }
    
    console.log('Fetching resources from database using admin client...');
    
    // Use a timeout to prevent hanging in serverless environments
    let timedOut = false;
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => {
        timedOut = true;
        reject(new Error('Resources query timed out'));
      }, 8000); // 8 second timeout instead of 4
    });
    
    try {
      // Always use the admin client for database access
      let query = adminSupabase.from('resources').select('*');
      
      // Apply filters
      if (subject) query = query.eq('subject', subject.toLowerCase());
      if (grade) query = query.eq('grade', grade.toLowerCase());
      if (type) query = query.eq('type', type.toLowerCase());
      if (search) query = query.ilike('title', `%${search}%`);
      
      // Order by most recent
      query = query.order('created_at', { ascending: false });
      
      // Log the query for debugging
      console.log('Running Supabase query for resources with filters:', { subject, grade, type, search });
      
      // Race the query against the timeout
      const { data, error } = await Promise.race([
        query,
        timeoutPromise
      ]) as { data: any[], error: any };
      
      if (error) {
        console.error('Database error:', error);
        console.error('Error details:', { code: error.code, message: error.message, details: error.details });
        
        // Handle table not exists errors
        if (error.code === '42P01' || error.message.includes('does not exist')) {
          console.log('Resources table does not exist');
          return NextResponse.json({
            resources: mockResources,
            demo: true,
            message: 'Resources table does not exist, using demo data',
            error: error.message
          });
        }
        
        throw error;
      }
      
      console.log(`Successfully retrieved ${data?.length || 0} resources`);
      
      return NextResponse.json({
        resources: data || [],
        count: data?.length || 0,
        demo: false,
        debug: {
          filters: { subject, grade, type, search },
          timestamp: new Date().toISOString(),
          environment: process.env.NODE_ENV
        }
      });
      
    } catch (queryError: any) {
      console.error('Error querying resources:', queryError);
      
      // If timeout occurred during production, return demo data
      if (timedOut && process.env.NODE_ENV === 'production') {
        console.log('Query timed out in production, using demo data');
        return NextResponse.json({
          resources: mockResources,
          demo: true,
          message: 'Database query timed out, using demo data'
        });
      }
      
      // Otherwise return appropriate error
      return NextResponse.json(
        {
          error: 'Failed to fetch resources: ' + queryError.message,
          resources: process.env.NODE_ENV === 'production' ? mockResources : [],
          demo: process.env.NODE_ENV === 'production'
        },
        { status: process.env.NODE_ENV === 'production' ? 200 : 500 }
      );
    }
  } catch (error: any) {
    console.error('Unexpected error in resources API:', error);
    
    // In production, return demo data to avoid breaking the app
    if (process.env.NODE_ENV === 'production') {
      return NextResponse.json({
        resources: mockResources,
        demo: true,
        message: 'Error occurred, using demo data',
        error: error.message
      });
    }
    
    return NextResponse.json(
      { error: 'Server error: ' + error.message },
      { status: 500 }
    );
  }
}
