import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js/dist/module/index';

// Get environment variables with fallbacks for safety
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const BUCKET_NAME = 'resources';

export async function POST(request: NextRequest) {
  try {
    // Create admin client
    const adminSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    
    // Parse the form data
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const fileName = formData.get('fileName') as string || `${Date.now()}-${file.name}`;
    
    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }
    
    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: 'File size must be less than 10MB' }, { status: 400 });
    }

    // Get file extension and validate
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt'];
    
    if (!fileExt || !allowedExtensions.includes(fileExt)) {
      return NextResponse.json(
        { error: 'Invalid file type. Allowed types: PDF, DOC, DOCX, PPT, PPTX, TXT' }, 
        { status: 400 }
      );
    }
    
    console.log("Converting file for upload...");
    // Convert File to ArrayBuffer for upload
    const arrayBuffer = await file.arrayBuffer();
    const fileBuffer = new Uint8Array(arrayBuffer);
    
    console.log("Uploading file to storage bucket...");
    const { data: uploadData, error: uploadError } = await adminSupabase.storage
      .from(BUCKET_NAME)
      .upload(fileName, fileBuffer, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type
      });
    
    if (uploadError) {
      console.error('Storage upload error:', uploadError);
      return NextResponse.json(
        { error: `Storage error: ${uploadError.message}` },
        { status: 500 }
      );
    }

    console.log("File uploaded successfully, getting public URL...");
    // Get file URL
    const { data: { publicUrl } } = adminSupabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(fileName);
    
    // Return success with the public URL
    return NextResponse.json({
      success: true,
      fileName,
      publicUrl
    });
    
  } catch (error) {
    console.error("Error in upload API:", error);
    return NextResponse.json(
      { error: 'An unexpected error occurred while processing your request' },
      { status: 500 }
    );
  }
} 