'use client';

import { useEffect } from 'react';
import Link from 'next/link';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <div className="flex h-screen w-full flex-col items-center justify-center">
      <h2 className="mb-4 text-center text-2xl font-bold">Something went wrong!</h2>
      <div className="flex flex-col items-center space-y-4">
        <button
          onClick={reset}
          className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-500"
        >
          Try again
        </button>
        <Link
          href="/"
          className="text-sm text-gray-600 underline underline-offset-2"
        >
          Return to Home
        </Link>
      </div>
    </div>
  );
} 