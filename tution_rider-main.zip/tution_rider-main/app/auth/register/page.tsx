'use client';

import { RegisterForm } from '@/app/components/forms/register-form';
import { Logo } from '@/app/components/shared/logo';
import Link from 'next/link';
import { Star, Gift, Medal, Shield } from 'lucide-react';

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -left-[10%] -top-[40%] size-[60%] rounded-full bg-blue-100/20 blur-3xl" />
        <div className="absolute -bottom-[40%] -right-[10%] size-[60%] rounded-full bg-emerald-100/20 blur-3xl" />
      </div>
      
      {/* Left side - Tuition Rider information */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex flex-col justify-center">
        <div className="max-w-md mx-auto">
          <Link href="/" className="inline-block mb-8">
            <Logo className="h-12 w-12" />
          </Link>
          
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mb-4">
            Join Tuition Rider Today
          </h1>
          
          <p className="text-slate-600 mb-8">
            Create your account and gain access to India's top tutoring platform with expert teachers for grades 1-12.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-start">
              <Medal className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Expert Tutors</h3>
                <p className="text-slate-600 text-sm">Connect with qualified tutors with proven teaching experience and subject expertise.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Star className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Proven Results</h3>
                <p className="text-slate-600 text-sm">95% of our students see grade improvements within the first 3 months.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Gift className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Free Trial Class</h3>
                <p className="text-slate-600 text-sm">Try a free session with a tutor to ensure it's the right fit before committing.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Shield className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Safe and Reliable</h3>
                <p className="text-slate-600 text-sm">Our tutors are background-checked and our platform provides a secure learning environment.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side - Registration form */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex items-center justify-center">
        <div className="w-full max-w-md bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-white/50 p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Create an account
            </h2>
            <p className="mt-2 text-slate-600 text-sm">
              Start your journey to academic excellence
            </p>
          </div>
          
          <RegisterForm />
          
          <div className="mt-6 text-center text-sm">
            <span className="text-slate-600">Already have an account?</span>{' '}
            <Link href="/auth/login" className="font-medium text-blue-600 hover:text-blue-500">
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
} 