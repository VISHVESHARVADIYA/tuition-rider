'use client';

import { LoginForm } from '@/app/components/forms/login-form';
import { Logo } from '@/app/components/shared/logo';
import Link from 'next/link';
import { Settings, BarChart, Users, FileEdit } from 'lucide-react';

export default function AdminLoginPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -left-[10%] -top-[40%] size-[60%] rounded-full bg-blue-100/20 blur-3xl" />
        <div className="absolute -bottom-[40%] -right-[10%] size-[60%] rounded-full bg-emerald-100/20 blur-3xl" />
      </div>
      
      {/* Left side - Admin portal information */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex flex-col justify-center">
        <div className="max-w-md mx-auto">
          <Link href="/" className="inline-block mb-8">
            <Logo className="h-12 w-12" />
          </Link>
          
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mb-4">
            Tuition Rider Admin Portal
          </h1>
          
          <p className="text-slate-600 mb-8">
            Welcome to the administration dashboard. Manage your tutoring platform with powerful tools and insights.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-start">
              <BarChart className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Analytics Dashboard</h3>
                <p className="text-slate-600 text-sm">Access real-time data on student performance, tutor ratings, and business metrics.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Users className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">User Management</h3>
                <p className="text-slate-600 text-sm">Manage accounts, review tutor applications, and handle student registrations.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <FileEdit className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Content Management</h3>
                <p className="text-slate-600 text-sm">Update website content, learning resources, and educational materials.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Settings className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">System Configuration</h3>
                <p className="text-slate-600 text-sm">Customize platform settings, manage payments, and configure email notifications.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side - Admin login form */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex items-center justify-center">
        <div className="w-full max-w-md bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-white/50 p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Admin Login
            </h2>
            <p className="mt-2 text-slate-600 text-sm">
              Enter your credentials to access the admin panel
            </p>
          </div>
          
          <LoginForm type="admin" />
          
          <div className="mt-6 text-center text-sm">
            <Link href="/" className="font-medium text-blue-600 hover:text-blue-500">
              Return to home page
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
} 