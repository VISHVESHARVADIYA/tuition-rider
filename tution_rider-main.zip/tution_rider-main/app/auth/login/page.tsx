'use client';

import { LoginForm } from '@/app/components/forms/login-form';
import { Logo } from '@/app/components/shared/logo';
import Link from 'next/link';
import { CheckCircle2, GraduationCap, Clock, Users } from 'lucide-react';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -left-[10%] -top-[40%] size-[60%] rounded-full bg-blue-100/20 blur-3xl" />
        <div className="absolute -bottom-[40%] -right-[10%] size-[60%] rounded-full bg-emerald-100/20 blur-3xl" />
      </div>
      
      {/* Left side - Tuition Rider information */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex flex-col justify-center">
        <div className="max-w-md mx-auto">
          <Link href="/" className="inline-block mb-8">
            <Logo className="h-12 w-12" />
          </Link>
          
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mb-4">
            Welcome to Tuition Rider
          </h1>
          
          <p className="text-slate-600 mb-8">
            Join the leading tutoring platform that connects students with expert tutors for personalized learning experiences.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-start">
              <CheckCircle2 className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Qualified Tutors</h3>
                <p className="text-slate-600 text-sm">All our tutors undergo a rigorous verification process to ensure quality education.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <GraduationCap className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Personalized Learning</h3>
                <p className="text-slate-600 text-sm">Customized lesson plans tailored to each student's unique learning needs.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Clock className="h-6 w-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Flexible Scheduling</h3>
                <p className="text-slate-600 text-sm">Book sessions at times that work for you, with options for both online and offline classes.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Users className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-800 mb-1">Community Support</h3>
                <p className="text-slate-600 text-sm">Join a community of students and educators committed to academic excellence.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side - Login form */}
      <div className="relative w-full md:w-1/2 p-6 md:p-12 flex items-center justify-center">
        <div className="w-full max-w-md bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-white/50 p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Sign in to your account
            </h2>
            <p className="mt-2 text-slate-600 text-sm">
              Enter your credentials to access your account
            </p>
          </div>
          
          <LoginForm type="user" />
          
          <div className="mt-6 text-center text-sm">
            <span className="text-slate-600">Don't have an account?</span>{' '}
            <Link href="/auth/register" className="font-medium text-blue-600 hover:text-blue-500">
              Sign up
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
} 