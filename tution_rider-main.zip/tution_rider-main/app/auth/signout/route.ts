import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import type { Database } from '@/app/lib/database.types'

export const dynamic = "force-dynamic"

export async function POST() {
  try {
    // Properly await the cookies() function to fix the error
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient<Database>({
      cookies: () => cookieStore
    })
    
    // Sign out the user
    await supabase.auth.signOut()
    
    // Clear any admin cookies we've set
    const response = NextResponse.redirect(new URL('/', new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000')));
    response.cookies.set('admin-auth', '', { 
      expires: new Date(0),
      path: '/'
    });
    
    return response
  } catch (error) {
    console.error('Sign out error:', error)
    return NextResponse.redirect(new URL('/', new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000')));
  }
} 