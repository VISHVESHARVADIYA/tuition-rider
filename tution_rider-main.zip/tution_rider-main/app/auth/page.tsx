'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Logo } from '@/app/components/shared/logo';

export default function AuthPage() {
  const router = useRouter();

  useEffect(() => {
    router.push('/auth/login');
  }, [router]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 via-white to-emerald-50 py-12 px-4 sm:px-6 lg:px-8">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -left-[10%] -top-[40%] size-[60%] rounded-full bg-blue-100/20 blur-3xl" />
        <div className="absolute -bottom-[40%] -right-[10%] size-[60%] rounded-full bg-emerald-100/20 blur-3xl" />
      </div>
      
      <div className="relative w-full max-w-md space-y-8 p-8 bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-white/50 flex flex-col items-center">
        <Logo className="h-16 w-16" />
        
        <div className="text-center">
          <h2 className="mt-4 text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
            Redirecting...
          </h2>
          <p className="mt-2 text-gray-600">
            Please wait while we redirect you to the login page
          </p>
        </div>
        
        <div className="mt-4 flex justify-center">
          <div className="h-8 w-8 border-4 border-t-transparent border-blue-600 rounded-full animate-spin" />
        </div>
      </div>
    </div>
  );
} 