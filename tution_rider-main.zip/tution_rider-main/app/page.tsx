import { SiteFooter } from "@/app/components/layout/site-footer";
import { NavBar } from "@/app/components/layout/navbar";
import { MarketingPopup } from "@/app/components/shared/marketing-popup";
import { Hero } from "@/app/components/sections/hero";
import { WhyHomeTutor } from "@/app/components/sections/why-home-tutor";
import { SubjectGrid } from "@/app/components/sections/subject-grid";
import { ServiceAreas } from "@/app/components/sections/service-areas";
import { Features } from "@/app/components/sections/features";
import { FAQ } from "@/app/components/sections/faq";
import { ContactUs } from "@/app/components/sections/contact-us";
import { HowWeWork } from "@/app/components/sections/how-we-work";
import { Reviews } from "@/app/components/sections/reviews";
import { WhatsAppButton } from "@/app/components/shared/whatsapp-button";

// Removing the dynamic directive for static export
// export const dynamic = 'force-dynamic';

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <NavBar scroll />
      <main className="flex-1">
        <div className="flex min-h-screen flex-col">
          <Hero />
          <Features />
          <WhyHomeTutor />
          <SubjectGrid />
          <HowWeWork />
          <ServiceAreas />
          <FAQ />
          <ContactUs />
          <Reviews />
          <WhatsAppButton />
        </div>
      </main>
      <SiteFooter />
      <MarketingPopup />
    </div>
  );
} 