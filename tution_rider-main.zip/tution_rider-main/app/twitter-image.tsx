import { ImageResponse } from 'next/og';
import { siteConfig } from '@/config/site';

export const runtime = 'edge';
export const alt = 'Tuition Rider - Find Expert Home Tutors Near You';
export const contentType = 'image/png';
export const size = {
  width: 1200,
  height: 630,
};

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          display: 'flex',
          background: 'linear-gradient(90deg, #4f46e5 0%, #7e3af2 100%)',
          width: '100%',
          height: '100%',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          position: 'relative',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 30,
          }}
        >
          <img
            src={`${siteConfig.url}/logo-white.png`}
            alt="Tuition Rider Logo"
            width={100}
            height={100}
          />
        </div>
        <h1
          style={{
            fontSize: 64,
            fontWeight: 'bold',
            color: 'white',
            marginBottom: 15,
            textAlign: 'center',
            padding: '0 20px',
          }}
        >
          Find Expert Home Tutors
        </h1>
        <p
          style={{
            fontSize: 28,
            color: 'white',
            opacity: 0.9,
            textAlign: 'center',
            padding: '0 40px',
          }}
        >
          Professional tutoring for all subjects & grades
        </p>
        <div
          style={{
            position: 'absolute',
            bottom: 25,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <p style={{ color: 'white', fontSize: 22 }}>
            www.tuitionrider.com
          </p>
        </div>
      </div>
    ),
    {
      ...size,
    }
  );
} 