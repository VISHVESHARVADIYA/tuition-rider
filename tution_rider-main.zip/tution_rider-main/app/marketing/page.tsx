import { Metadata } from "next";

import { Hero } from "@/app/components/sections/hero"
import { WhyHomeTutor } from "@/app/components/sections/why-home-tutor"
import { SubjectGrid } from "@/app/components/sections/subject-grid"
import { ServiceAreas } from "@/app/components/sections/service-areas"
import { Features } from "@/app/components/sections/features"
import { FAQ } from "@/app/components/sections/faq"
import { ContactUs } from "@/app/components/sections/contact-us"
import { HowWeWork } from "@/app/components/sections/how-we-work"
import { Reviews } from "@/app/components/sections/reviews"
import { WhatsAppButton } from "@/app/components/shared/whatsapp-button"


export const metadata = {
  title: "Home",
  description: "Welcome to Tuition Rider",
};

export default async function MarketingPage() {
  return (
    <main className="flex min-h-screen flex-col">
      <Hero />
      <Features />
      <WhyHomeTutor />
      <SubjectGrid />
      {/* <CurriculumGrid /> */}
      <HowWeWork />
      <ServiceAreas />
      <FAQ />
      <ContactUs />
      <Reviews />
      <WhatsAppButton />
    </main>
  );
}
