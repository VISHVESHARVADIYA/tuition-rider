"use client"

import { ComingSoon } from "@/app/components/sections/coming-soon"
import { WhatsAppButton } from "@/app/components/shared/whatsapp-button"
import { HeaderSection } from "@/app/components/shared/header-section"
import Container from "@/app/components/shared/container"

export default function BlogPage() {
  return (
    <main className="flex min-h-screen flex-col">
      <section className="relative w-full overflow-hidden bg-gradient-to-b from-blue-50 via-white to-emerald-50/30 py-16 md:py-24">
        <Container>
          <HeaderSection
            title="Educational Insights"
            subtitle="Discover articles, tips, and resources to enhance your learning journey"
            centered
          />
        </Container>
      </section>

      <ComingSoon 
        title="Blog Coming Soon"
        description="We're preparing insightful articles and educational content. Check back soon!"
      />
      <WhatsAppButton />
    </main>
  )
} 