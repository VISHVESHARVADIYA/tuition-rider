"use client"

import { Suspense } from "react"
import { Reviews } from "@/app/components/sections/reviews"
import { WhatsAppButton } from "@/app/components/shared/whatsapp-button"

function LoadingFallback() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center">
      <div className="container mx-auto p-4 animate-pulse">
        <div className="max-w-4xl mx-auto">
          <div className="h-8 w-48 bg-gray-200 rounded mb-4 mx-auto"></div>
          <div className="h-4 w-3/4 bg-gray-200 rounded mb-8 mx-auto"></div>
          <div className="space-y-8">
            <div className="h-64 bg-gray-200 rounded-lg"></div>
            <div className="h-64 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ReviewsPage() {
  return (
    <main className="flex min-h-screen flex-col">
      <Suspense fallback={<LoadingFallback />}>
        <Reviews />
      </Suspense>
      <WhatsAppButton />
    </main>
  )
} 