import { notFound } from "next/navigation";

interface PageProps {
  params: {
    slug: string;
  };
}

interface StaticPage {
  title: string;
  content: string;
}

// Updated pages object - removed privacy and terms as they have dedicated routes
const pages: Record<string, StaticPage> = {
  "careers": {
    title: "Careers at Tuition Rider",
    content: "We're always looking for talented teachers and staff to join our team. Check back soon for open positions.",
  },
  "impact": {
    title: "Our Impact",
    content: "Learn about how Tuition Rider is making a difference in education.",
  },
  "partners": {
    title: "Our Partners",
    content: "Information about our educational partners and collaborations.",
  }
};

// Make the component async to properly handle params
export default async function Page({ params }: PageProps) {
  // Properly declare and await params
  const slug = params?.slug;
  
  // If slug doesn't exist, show 404
  if (!slug) {
    notFound();
  }

  // Check if the page exists
  const page = pages[slug];
  
  // If page doesn't exist, show 404
  if (!page) {
    notFound();
  }

  return (
    <article className="container max-w-3xl py-6 lg:py-12">
      <div className="space-y-4">
        <h1 className="inline-block font-heading text-4xl lg:text-5xl">
          {page.title}
        </h1>
        <div className="prose max-w-none dark:prose-invert">
          {page.content}
        </div>
      </div>
    </article>
  );
}

// This function is required for static export of dynamic routes
export function generateStaticParams() {
  return Object.keys(pages).map((slug) => ({ slug }));
}
