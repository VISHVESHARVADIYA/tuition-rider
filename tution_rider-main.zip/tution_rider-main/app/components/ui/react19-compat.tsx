'use client'

import * as React from 'react'

/**
 * Higher-order component to make Radix UI components compatible with React 19
 * 
 * This HOC wraps components to properly handle refs in React 19, which has 
 * deprecated element.ref access. Instead, we use forwardRef pattern to
 * directly pass the ref to the component as a regular prop.
 * 
 * This approach avoids the warning:
 * "Accessing element.ref was removed in React 19. ref is now a regular prop."
 */
export function withReact19Compat<T extends React.ComponentType<any>>(
  Component: T
): any {
  // For function components, create a proper forwardRef wrapper
  if (typeof Component === 'function') {
    const WrappedComponent = React.forwardRef((props, ref) => {
      // Pass ref as a regular prop without referencing element.ref internally
      return React.createElement(Component, { ...props, ref });
    });

    // Copy display name for better debugging
    WrappedComponent.displayName = `React19Compatible(${
      Component.displayName || Component.name || 'Component'
    })`;

    return WrappedComponent;
  }

  // For non-function components (including already forwardRef components),
  // return as is without wrapping
  return Component;
}