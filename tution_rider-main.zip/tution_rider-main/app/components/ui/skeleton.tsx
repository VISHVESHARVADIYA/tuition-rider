import * as React from "react";
import { cn } from "@/app/lib/utils"


interface SkeletonProps {
  className?: string;
}

function Skeleton({ className, ...props }: SkeletonProps) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-muted", className)}
      {...props}
    />
  )
}
Skeleton.displayName = "Skeleton"

export { Skeleton };