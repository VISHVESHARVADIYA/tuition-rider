'use client'

import * as React from 'react'
import { Slot as RadixSlot } from '@radix-ui/react-slot'

export interface SlotProps extends React.ComponentPropsWithoutRef<typeof RadixSlot> {}

/**
 * This component passes its children's props to its first child
 */
export const Slot = React.forwardRef<HTMLElement, SlotProps>(
  (props, ref) => {
    return <RadixSlot {...props} ref={ref} />
  }
)

Slot.displayName = 'Slot'