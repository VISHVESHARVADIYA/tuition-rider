'use client';

import { ChevronRight, Home } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect } from 'react';
import { siteConfig } from '@/config/site';

interface BreadcrumbItem {
  href: string;
  label: string;
}

export default function Breadcrumbs() {
  const pathname = usePathname();
  
  // Skip rendering breadcrumbs on homepage
  if (pathname === '/') return null;
  
  // Generate breadcrumb items from pathname
  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    const asPathWithoutQuery = pathname.split('?')[0];
    const asPathNestedRoutes = asPathWithoutQuery.split('/')
      .filter(v => v.length > 0);
    
    // Create breadcrumb items array
    const crumblist = asPathNestedRoutes.map((subpath, idx) => {
      // Build the path up to this point
      const href = '/' + asPathNestedRoutes.slice(0, idx + 1).join('/');
      
      // Convert to readable label (capitalize, replace hyphens, etc.)
      let label = subpath.replace(/-/g, ' ');
      
      // Handle special case for dynamic route segments
      if (label.startsWith('[') && label.endsWith(']')) {
        label = 'Details';
      }
      
      // Capitalize first letter
      label = label.charAt(0).toUpperCase() + label.slice(1);
      
      return { href, label };
    });
    
    // Add home page
    return [{ href: '/', label: 'Home' }, ...crumblist];
  };
  
  const breadcrumbs = generateBreadcrumbs();
  
  // Add JSON-LD schema for breadcrumbs
  useEffect(() => {
    const breadcrumbSchema = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: breadcrumbs.map((crumb, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        item: {
          '@id': `${siteConfig.url}${crumb.href}`,
          name: crumb.label
        }
      }))
    };
    
    // Add schema to page
    const existingScript = document.getElementById('breadcrumb-schema');
    if (existingScript) {
      document.head.removeChild(existingScript);
    }
    
    const script = document.createElement('script');
    script.id = 'breadcrumb-schema';
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify(breadcrumbSchema);
    document.head.appendChild(script);
    
    return () => {
      const script = document.getElementById('breadcrumb-schema');
      if (script) {
        document.head.removeChild(script);
      }
    };
  }, [pathname]);
  
  return (
    <nav aria-label="Breadcrumb" className="py-2 px-4 text-sm text-muted-foreground">
      <ol className="flex flex-wrap items-center gap-1">
        {breadcrumbs.map((crumb, idx) => (
          <li key={idx} className="flex items-center">
            {idx > 0 && <ChevronRight className="h-4 w-4 mx-1" />}
            {idx === 0 ? (
              <Link href={crumb.href} className="flex items-center hover:text-primary transition-colors">
                <Home className="h-4 w-4 mr-1" />
                <span className="sr-only">{crumb.label}</span>
              </Link>
            ) : idx === breadcrumbs.length - 1 ? (
              <span aria-current="page" className="font-medium text-foreground">
                {crumb.label}
              </span>
            ) : (
              <Link href={crumb.href} className="hover:text-primary transition-colors">
                {crumb.label}
              </Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
} 