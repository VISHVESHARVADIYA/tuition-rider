'use client';

import { useEffect } from 'react';
import { siteConfig } from '@/config/site';

// This component creates and injects JSON-LD structured data into the document head
// for improved SEO and rich search results
const StructuredData = () => {
  useEffect(() => {
    // Organization data
    const organizationData = {
      '@context': 'https://schema.org',
      '@type': 'EducationalOrganization',
      '@id': `${siteConfig.url}/#organization`,
      name: 'Tuition Rider',
      url: siteConfig.url,
      logo: {
        '@type': 'ImageObject',
        url: `${siteConfig.url}/logo.png`,
        width: '200',
        height: '60'
      },
      sameAs: [
        siteConfig.links.twitter,
        siteConfig.links.facebook,
        siteConfig.links.instagram,
        siteConfig.links.linkedin
      ],
      contactPoint: {
        '@type': 'ContactPoint',
        telephone: '+91-8800787878',
        contactType: 'customer service',
        availableLanguage: ['English', 'Hindi']
      }
    };

    // Website data
    const websiteData = {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      '@id': `${siteConfig.url}/#website`,
      name: 'Tuition Rider - Professional Home Tutoring',
      url: siteConfig.url,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${siteConfig.url}/search?q={search_term_string}`,
        'query-input': 'required name=search_term_string'
      }
    };

    // Navigation data
    const navigationData = {
      '@context': 'https://schema.org',
      '@type': 'SiteNavigationElement',
      '@id': `${siteConfig.url}/#main-navigation`,
      name: [
        'Home', 
        'Find a Tutor', 
        'Become a Tutor', 
        'How It Works', 
        'Pricing', 
        'About Us', 
        'Contact'
      ],
      url: [
        `${siteConfig.url}/`,
        `${siteConfig.url}/find-tutor`,
        `${siteConfig.url}/become-tutor`,
        `${siteConfig.url}/how-it-works`,
        `${siteConfig.url}/pricing`,
        `${siteConfig.url}/about`,
        `${siteConfig.url}/contact`
      ]
    };

    // Create and append script elements to the document head
    const scripts = [
      { id: 'organization-data', data: organizationData },
      { id: 'website-data', data: websiteData },
      { id: 'navigation-data', data: navigationData }
    ];

    scripts.forEach(({ id, data }) => {
      const existingScript = document.getElementById(id);
      if (existingScript) {
        existingScript.remove();
      }
      
      const script = document.createElement('script');
      script.id = id;
      script.type = 'application/ld+json';
      script.text = JSON.stringify(data);
      document.head.appendChild(script);
    });

    // Cleanup on component unmount
    return () => {
      scripts.forEach(({ id }) => {
        const script = document.getElementById(id);
        if (script) {
          script.remove();
        }
      });
    };
  }, []);

  return null; // This component doesn't render anything visible
};

export default StructuredData; 