"use client";

import * as React from "react";
import { useState, useEffect, useCallback, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  User as UserIcon,
  LogOut,
  ChevronDown,
  Sparkles,
  Search,
  BookOpen,
  Book,
  Users,
  MessageSquare,
  Shield,
  FileText,
  Menu,
  X
} from "lucide-react";

import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { Button } from "@/app/components/ui/button";
import { cn } from "@/app/lib/utils";
import { Logo } from "@/app/components/shared/logo";
import { ClientOnly } from "./client-only";
//import { checkAuth, getUserRole, isAdmin as checkIsAdmin } from "@/lib/auth-check";
import { useUserAuth } from "@/app/lib/hooks/use-user-auth";
import { clsx } from "clsx";

// Create a single instance of Supabase client outside component to avoid multiple instances warning
const supabase = createClientComponentClient();

interface NavBarProps {
  scroll?: boolean;
}

// Memoized link component to prevent unnecessary re-renders
const NavLink = React.memo(({ href, children, className, onClick }: { href: string, children: React.ReactNode, className?: string, onClick?: () => void }) => (
  <Link href={href} className={className} onClick={onClick}>
    {children}
  </Link>
));
NavLink.displayName = "NavLink";

export const NavBar: React.FC<NavBarProps> = React.memo(({ scroll = false }) => {
  const router = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);
  
  // Use our auth hook for authentication state
  const { 
    isAuthenticated, 
    isAdmin, 
    user, 
    isLoading, 
    isLoggingOut, 
    logout,
    recheckAuth 
  } = useUserAuth();
  
  // Mobile menu state with straightforward boolean
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  
  // Very simple toggle function - no fancy logic
  function toggleMobileMenu() {
    setShowMobileMenu(!showMobileMenu);
  }
  
  // Simple close function that will be used by menu items
  function closeMobileMenu() {
    setShowMobileMenu(false);
  }

  // Scroll effect - only in browser
  useEffect(() => {
    // Skip this effect on server-side rendering
    if (typeof window === 'undefined') return;

    const handleScroll = () => setIsScrolled(window.scrollY > 0);
    window.addEventListener("scroll", handleScroll);

    // Initial check
    setIsScrolled(window.scrollY > 0);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Check for auth changes when the component mounts - only in browser
  useEffect(() => {
    // Skip this effect on server-side rendering
    if (typeof window === 'undefined') return;
    
    // Only log in development
    if (process.env.NODE_ENV === 'development') {
      console.log('[NavBar] Mounted. Auth status:', { isAuthenticated, isAdmin, user: !!user });
    }
    
    // Visibility change listener to recheck auth when tab becomes visible again
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Auth check interval - if we have cookies but no auth state, trigger a recheck
    const interval = setInterval(() => {
      const hasAuthToken = document.cookie.includes('auth-token');
      const hasUserRole = document.cookie.includes('user-role');
      
      // Only log in development
      if (process.env.NODE_ENV === 'development') {
        console.log('[NavBar] Auth check interval:', {
          hasAuthToken,
          hasUserRole,
          isAuthenticated, 
          isAdmin,
          hasUser: !!user
        });
      }
      
      // If we have auth token cookie but not authenticated, recheck
      if (hasAuthToken && !isAuthenticated) {
        if (process.env.NODE_ENV === 'development') {
          console.log('[NavBar] Found auth cookies but not authenticated, rechecking from navbar');
        }
        recheckAuth();
      }
      
      // If we're authenticated but don't have user data, trigger a recheck
      if (isAuthenticated && !user && !isLoading) {
        if (process.env.NODE_ENV === 'development') {
          console.log('[NavBar] Authenticated but missing user data, rechecking from navbar');
        }
        recheckAuth();
      }
    }, 10000); // 10 second interval
    
    // Cleanup
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(interval);
    };
  }, [isAuthenticated, isAdmin, user, isLoading, recheckAuth]);
  
  // Handle visibility change
  const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible') {
      if (process.env.NODE_ENV === 'development') {
        console.log('[NavBar] Visibility changed to visible, rechecking auth');
      }
      recheckAuth();
    }
  };

  // Pre-compute header class to avoid computation during render
  const headerClass = useMemo(() => cn(
    "sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
    isScrolled && "border-b shadow-sm"
  ), [isScrolled]);

  // Calculate userName outside of the render flow to prevent hook errors
  const userNameValue = useMemo(() => {
    // First try to get name from auth state
    if (user?.fullName || user?.full_name || user?.name) {
      return user.fullName || user.full_name || user.name;
    }

    // Then try email
    if (user?.email) {
      return user.email.split('@')[0];
    }
    
    // Try localStorage as fallback
    if (typeof window !== 'undefined') {
      try {
        const storedUserInfo = localStorage.getItem('userInfo');
        if (storedUserInfo) {
          const { fullName, email, name } = JSON.parse(storedUserInfo);
          if (fullName) return fullName;
          if (name) return name;
          if (email) return email.split('@')[0];
        }
      } catch (e) {
        console.error('Error reading from localStorage:', e);
      }
    }
    
    // Check for auth token and user role in cookies directly - only in browser
    const hasUserRole = typeof window !== 'undefined' ? document.cookie.includes('user-role') : false;
    
    // Finally use cookie info or default
    return (hasUserRole && typeof window !== 'undefined' && 
      document.cookie.includes('user-role=ADMIN')) ? 'Admin' : 'User';
  }, [user]);

  // Auth button renderer - converted from useMemo to regular function
  const renderAuthButtons = () => {
    // Check for auth token and user role in cookies directly - only in browser
    const hasAuthToken = typeof window !== 'undefined' ? document.cookie.includes('auth-token') : false;
    const hasUserRole = typeof window !== 'undefined' ? document.cookie.includes('user-role') : false;
    const isActuallyAuthenticated = isAuthenticated;

    if (isLoading) {
      return <div className="h-9 w-24 animate-pulse bg-slate-100 rounded-md"></div>;
    }

    // If authenticated by any means, show user info
    if (isActuallyAuthenticated) {
      // If we're authenticated but don't have user data, trigger a recheck
      if (!user && !isLoading) {
        if (process.env.NODE_ENV === 'development') {
          console.log('[renderAuthButtons] Authenticated but no user data, rechecking...');
        }
        setTimeout(() => recheckAuth(), 100);
      }

      return (
        <div className="flex items-center space-x-4">
          {/* Admin section - only show if user is admin */}
          {(isAdmin || (hasUserRole && typeof window !== 'undefined' && document.cookie.includes('user-role=ADMIN'))) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="font-medium bg-gradient-to-r from-blue-50 to-emerald-50 hover:from-blue-100 hover:to-emerald-100"
                  size="default">
                  Admin
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-48 bg-white/95 backdrop-blur-sm border-t-2 border-t-blue-500">
                <NavLink href="/admin" className="w-full hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    Dashboard
                  </div>
                </NavLink>
                <NavLink href="/admin/resources" className="w-full hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    Resources
                  </div>
                </NavLink>
                <NavLink href="/admin/users" className="w-full hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    Users
                  </div>
                </NavLink>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {/* User dropdown with name */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 px-3 py-1.5 hover:bg-gradient-to-r hover:from-blue-50 hover:to-emerald-50 min-w-0 w-auto overflow-visible" size="default">
                <UserIcon className="w-4 h-4 text-blue-600 flex-shrink-0" />
                <span className="font-medium text-slate-700 inline-block whitespace-nowrap overflow-visible">
                  {userNameValue}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-white/95 backdrop-blur-sm">
              <button
                onClick={logout}
                disabled={isLoggingOut}
                className="relative flex w-full cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-red-50 hover:text-red-600"
              >
                {isLoggingOut ? (
                  <>
                    <div className="w-4 h-4 mr-2 border-2 border-t-transparent border-blue-600 rounded-full animate-spin" />
                    <span>Logging out...</span>
                  </>
                ) : (
                  <>
                    <LogOut className="w-4 h-4 mr-2" />
                    <span>Logout</span>
                  </>
                )}
              </button>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    } else {
      // Not authenticated, show sign in/sign up buttons
      return (
        <div className="flex items-center space-x-4">
          <NavLink href="/auth/login">
            <Button
              variant="ghost"
              className="flex items-center mr-2 px-3 py-1.5 font-medium bg-blue-50 text-blue-600 hover:bg-blue-100"
              size="default">
              Sign In
            </Button>
          </NavLink>
          <NavLink href="/auth/register">
            <Button
              className="flex items-center px-3 py-1.5 font-medium bg-blue-600 text-white hover:bg-blue-700 border border-blue-600"
              size="default">
              Sign Up
            </Button>
          </NavLink>
        </div>
      );
    }
  };

  return (
    <>
      {/* ULTRA SIMPLE MOBILE MENU - DISPLAYED WHEN SHOWN */}
      {showMobileMenu && (
        <div 
          className="fixed inset-0 bg-white z-[9999] overflow-auto p-4"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'white', zIndex: 9999 }}
        >
          <div className="max-w-screen-xl mx-auto">
            <div className="flex justify-between items-center mb-8 border-b pb-4">
              <div onClick={() => { router.push('/'); closeMobileMenu(); }} className="flex items-center gap-2">
                <Logo className="h-8 w-8" />
                <span className="font-bold text-xl">Tuition Rider</span>
              </div>
              
              <button 
                onClick={closeMobileMenu}
                className="p-2 rounded-full bg-slate-100 hover:bg-slate-200"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-6">
              <NavLink 
                href="/contact" 
                onClick={closeMobileMenu}
                className="block p-3 text-lg font-medium border-b border-slate-100"
              >
                Find Tutor
              </NavLink>
              
              <div>
                <h3 className="font-medium text-slate-500 mb-2">Services</h3>
                <NavLink 
                  href="/services" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Our Services
                </NavLink>
                <NavLink 
                  href="/curriculum" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Curriculum
                </NavLink>
              </div>
              
              <div>
                <h3 className="font-medium text-slate-500 mb-2">Learning</h3>
                <NavLink 
                  href="/resources" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Learning Resources
                </NavLink>
                <NavLink 
                  href="/courses" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Courses
                </NavLink>
              </div>
              
              <NavLink 
                href="/reviews" 
                onClick={closeMobileMenu}
                className="block p-3 text-lg font-medium border-b border-slate-100"
              >
                Reviews
              </NavLink>
              
              <div>
                <h3 className="font-medium text-slate-500 mb-2">About</h3>
                <NavLink 
                  href="/about" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  About Us
                </NavLink>
                <NavLink 
                  href="/contact" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Contact
                </NavLink>
                <NavLink 
                  href="/privacy-policy" 
                  onClick={closeMobileMenu}
                  className="block p-3 hover:bg-slate-50 rounded-md"
                >
                  Privacy Policy
                </NavLink>
              </div>
              
              <div className="mt-8 pt-4 border-t border-slate-200">
                {isAuthenticated ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 p-3">
                      <UserIcon className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">
                        {userNameValue}
                      </span>
                    </div>

                    {isAdmin && (
                      <div className="space-y-2 border-t border-b py-3">
                        <h3 className="font-medium text-slate-500 mb-2">Admin</h3>
                        <NavLink
                          href="/admin"
                          onClick={closeMobileMenu}
                          className="block p-3 hover:bg-slate-50 rounded-md"
                        >
                          Dashboard
                        </NavLink>
                        <NavLink
                          href="/admin/resources"
                          onClick={closeMobileMenu}
                          className="block p-3 hover:bg-slate-50 rounded-md"
                        >
                          Resources
                        </NavLink>
                        <NavLink
                          href="/admin/users"
                          onClick={closeMobileMenu}
                          className="block p-3 hover:bg-slate-50 rounded-md"
                        >
                          Users
                        </NavLink>
                      </div>
                    )}

                    <button
                      onClick={() => {
                        closeMobileMenu();
                        logout();
                      }}
                      disabled={isLoggingOut}
                      className="flex items-center gap-2 w-full p-3 text-red-600 hover:bg-red-50 rounded-md"
                    >
                      {isLoggingOut ? (
                        <>
                          <div className="h-5 w-5 border-2 border-t-transparent border-red-600 rounded-full animate-spin" />
                          <span>Logging out...</span>
                        </>
                      ) : (
                        <>
                          <LogOut className="h-5 w-5" />
                          <span>Logout</span>
                        </>
                      )}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3 p-2">
                    <NavLink href="/auth/login" className="w-full block mb-2" onClick={closeMobileMenu}>
                      <Button
                        variant="outline"
                        className="w-full"
                        size="default">
                        Sign In
                      </Button>
                    </NavLink>
                    <NavLink href="/auth/register" className="w-full block" onClick={closeMobileMenu}>
                      <Button
                        className="w-full font-medium bg-blue-600 text-white hover:bg-blue-700"
                        size="default">
                        Sign Up
                      </Button>
                    </NavLink>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REGULAR HEADER */}
      <header className={headerClass}>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50/50 via-white/50 to-emerald-50/50 pointer-events-none"></div>
        
        <nav className="container relative flex h-16 items-center">
          <div className="flex items-center gap-2">
            <div onClick={() => router.push('/')} className="flex items-center gap-2 cursor-pointer">
              <Logo className="h-8 w-8" />
              <span className="font-bold text-xl text-blue-600 hidden sm:inline-block">Tuition Rider</span>
            </div>
          </div>

          {/* Mobile Menu Button - simplified */}
          <div className="lg:hidden ml-auto">
            <button
              type="button"
              onClick={toggleMobileMenu}
              className="p-2 rounded-lg border text-slate-600 bg-slate-50"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1 ml-8 mr-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="inline-flex items-center gap-1 px-3 py-2 text-slate-600 hover:text-slate-900 font-medium">
                  Services
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <NavLink href="/services" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <Sparkles className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Our Services</span>
                  </div>
                </NavLink>
                <NavLink href="/curriculum" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <BookOpen className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Curriculum</span>
                  </div>
                </NavLink>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="inline-flex items-center gap-1 px-3 py-2 text-slate-600 hover:text-slate-900 font-medium">
                  Learning
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <NavLink href="/resources" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <FileText className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Learning Resources</span>
                  </div>
                </NavLink>
                <NavLink href="/courses" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <Book className="h-4 w-4 text-emerald-600 mr-2" />
                    <span>Courses</span>
                  </div>
                </NavLink>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="inline-flex items-center gap-1 px-3 py-2 text-slate-600 hover:text-slate-900 font-medium">
                  About
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <NavLink href="/about" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <Users className="h-4 w-4 text-blue-600 mr-2" />
                    <span>About Us</span>
                  </div>
                </NavLink>
                <NavLink href="/contact" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <MessageSquare className="h-4 w-4 text-emerald-600 mr-2" />
                    <span>Contact</span>
                  </div>
                </NavLink>
                <NavLink href="/privacy-policy" className="flex items-center gap-2 cursor-pointer">
                  <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent">
                    <Shield className="h-4 w-4 text-blue-600 mr-2" />
                    <span>Privacy Policy</span>
                  </div>
                </NavLink>
              </DropdownMenuContent>
            </DropdownMenu>

            <NavLink 
              href="/reviews" 
              className="px-3 py-2 text-slate-600 hover:text-slate-900 font-medium"
            >
              Reviews
            </NavLink>

            <NavLink 
              href="/contact" 
              className="px-3 py-2 text-slate-600 hover:text-slate-900 font-medium"
            >
              Find Tutor
            </NavLink>
          </div>

          {/* Desktop Auth Section */}
          <div className="hidden lg:flex items-center space-x-4 ml-auto overflow-visible">
            <ClientOnly>
              {renderAuthButtons()}
            </ClientOnly>
          </div>
        </nav>
      </header>
    </>
  );
});

NavBar.displayName = "NavBar"