"use client"

import * as React from "react";
import { Button } from "@/app/components/ui/button"
import { Card } from "@/app/components/ui/card"
import { useState, useEffect } from 'react'
import Link from "next/link"
import Image from "next/image"
import { GraduationCap, BookOpen, Users, Star, Trophy, Clock, Target, Sparkles, ArrowRight } from 'lucide-react'
import { motion } from "framer-motion"
import { ClientOnly } from "../layout/client-only"
import { FloatingStars } from "./floating-stars"

export interface HeroProps {
  className?: string;
}

export function Hero() {
  const [text, setText] = useState<string>('')
  const fullText = "Welcome to Tuition Rider"
  const highlightedText = ""
  const endText = "!"
  const [isDeleting, setIsDeleting] = useState<boolean>(false)
  const completeText = fullText + highlightedText + endText
  
  useEffect(() => {
    let timeout: NodeJS.Timeout

    if (!isDeleting && text === completeText) {
      timeout = setTimeout(() => {
        setIsDeleting(true)
      }, 2000)
    } else if (isDeleting && text === '') {
      setIsDeleting(false)
    } else {
      timeout = setTimeout(() => {
        setText(isDeleting ? text.slice(0, -1) : completeText.slice(0, text.length + 1))
      }, isDeleting ? 50 : 100)
    }

    return () => clearTimeout(timeout)
  }, [text, isDeleting, completeText])



  const renderText = () => {
    const index = text.indexOf(highlightedText)
    if (index === -1) return text

    return (
      <>
        {text.slice(0, index)}
        <span className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">{text.slice(index, index + highlightedText.length)}</span>
        {text.slice(index + highlightedText.length)}
      </>
    )
  }

  const features = [
    { icon: Star, label: "Personalized Learning", color: "from-yellow-400 to-orange-500" },
    { icon: Trophy, label: "Expert Tutors", color: "from-blue-500 to-indigo-600" },
    { icon: Clock, label: "Flexible Timing", color: "from-emerald-500 to-teal-600" },
    { icon: Target, label: "Goal Oriented", color: "from-red-500 to-pink-600" }
  ]

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-blue-50 via-white to-emerald-50/30">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -left-[10%] -top-[40%] w-[60%] h-[60%] rounded-full bg-blue-100/20 blur-3xl animate-pulse" />
        <div className="absolute -bottom-[40%] -right-[10%] w-[60%] h-[60%] rounded-full bg-emerald-100/20 blur-3xl animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.1),transparent_70%)]" />
        </div>
        {/* Floating stars - client-side only to prevent hydration mismatch */}
        <ClientOnly>
          <FloatingStars count={8} />
        </ClientOnly>
      </div>

      {/* Main content */}
      <div className="container relative mx-auto grid min-h-[85vh] grid-cols-1 gap-2 px-4 pt-16 pb-6 md:min-h-[90vh] md:grid-cols-2 md:gap-8 md:px-6 md:pt-20 md:pb-8">
        {/* Left Column - Content */}
        <div className="animate-fade-in-up flex flex-col justify-center space-y-1 pl-1 sm:pl-6 md:space-y-6 md:pl-8 lg:space-y-8">
          <div className="space-y-4 md:space-y-4">
            <div className="relative">
              <div className="absolute -left-2 -top-1 size-3 animate-bounce sm:-left-8 sm:-top-4 sm:size-8">
                <Sparkles className="size-full text-yellow-400" />
              </div>
              <div className="min-h-[60px] sm:min-h-[100px] md:min-h-[120px]">
                <h1 className="text-3xl font-bold tracking-tight text-slate-800 sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl">
                  {renderText()}<span className="animate-blink">|</span>
                </h1>
                <div className="h-8 sm:h-6 md:h-8 lg:h-10"></div>
                <h2 className="text-2xl font-semibold text-slate-700 sm:text-xl md:text-2xl lg:text-3xl">
                  <span className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">Personalized Tutoring Excellence</span>
                </h2>
              </div>
            </div>
            <div className="space-y-4 md:space-y-4">
              <p className="text-xl text-slate-600 sm:text-lg md:text-xl lg:text-2xl relative max-w-xl">
                Expert tutors helping your child excel academically
                <span className="absolute -right-2 top-0 text-xl animate-pulse sm:text-xl">✨</span>
              </p>

              <div className="mt-4 sm:mt-4 flex flex-row gap-3 sm:gap-4">
                <Link href="/contact">
                  <Button size="sm" className="bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white text-sm py-1.5 px-3 h-9 sm:py-2 sm:px-4 sm:h-10">
                    Get Started
                    <ArrowRight className="ml-1.5 h-3.5 w-3.5 sm:ml-2 sm:h-4 sm:w-4" />
                  </Button>
                </Link>
                <Link href="/services">
                  <Button size="sm" variant="outline" className="border-blue-200 text-blue-600 hover:bg-blue-50 text-sm py-1.5 px-3 h-9 sm:py-2 sm:px-4 sm:h-10">
                    Explore
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Feature Grid */}
          <div className="mt-6 sm:mt-6 grid grid-cols-2 gap-2 sm:gap-3 md:grid-cols-4 md:gap-4">
            {features.map((feature, index) => (
              <div key={feature.label} className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-100/50 to-emerald-100/50 rounded-lg blur-sm transition-all duration-300 group-hover:scale-105" />
                <div className="relative flex flex-col items-center p-2 sm:p-3 md:p-4 bg-white/90 rounded-lg border border-white shadow-sm backdrop-blur-sm transition-all duration-300 group-hover:transform group-hover:scale-105">
                  <div className={`size-5 sm:size-8 md:size-10 rounded-lg bg-gradient-to-br ${feature.color} p-1 sm:p-1.5 md:p-2 text-white shadow-md transition-transform duration-300 group-hover:scale-110`}>
                    <feature.icon className="size-full" />
                  </div>
                  <p className="mt-1 sm:mt-2 text-[10px] sm:text-xs font-medium text-slate-700 text-center">{feature.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Stats Cards */}
          <div className="flex flex-row w-full gap-2 sm:gap-4 md:gap-6 z-20 relative mt-4 sm:mt-5 md:mt-7">
            <Card className="flex-1 group relative rounded-lg border border-blue-100 bg-white shadow-md transition-all duration-300 hover:scale-105 hover:shadow-lg">
              <div className="flex items-center justify-center sm:justify-start p-2 sm:p-3 md:p-4">
                <div className="relative shrink-0 rounded-full bg-gradient-to-br from-blue-100 to-emerald-100 p-1 sm:p-2">
                  <Users className="size-3 sm:size-5 md:size-6 text-blue-600 transition-colors duration-300 group-hover:text-emerald-600" />
                </div>
                <div className="ml-1.5 sm:ml-3">
                  <div className="flex items-baseline justify-center sm:justify-start">
                    <p className="text-sm sm:text-lg md:text-2xl font-bold text-blue-600">250</p>
                    <p className="text-[8px] sm:text-xs font-semibold text-slate-800 ml-0.5">+</p>
                  </div>
                  <p className="text-[8px] sm:text-xs text-slate-600 leading-tight text-center sm:text-left">Expert Tutors</p>
                </div>
              </div>
            </Card>

            <Card className="flex-1 group relative rounded-lg border border-emerald-100 bg-white shadow-md transition-all duration-300 hover:scale-105 hover:shadow-lg">
              <div className="flex items-center justify-center sm:justify-start p-2 sm:p-3 md:p-4">
                <div className="relative shrink-0 rounded-full bg-gradient-to-br from-emerald-100 to-blue-100 p-1 sm:p-2">
                  <BookOpen className="size-3 sm:size-5 md:size-6 text-emerald-600 transition-colors duration-300 group-hover:text-blue-600" />
                </div>
                <div className="ml-1.5 sm:ml-3">
                  <div className="flex items-baseline justify-center sm:justify-start">
                    <p className="text-sm sm:text-lg md:text-2xl font-bold text-emerald-600">10K</p>
                    <p className="text-[8px] sm:text-xs font-semibold text-slate-800 ml-0.5">+</p>
                  </div>
                  <p className="text-[8px] sm:text-xs text-slate-600 leading-tight text-center sm:text-left">Teaching Hours</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Right Column - Illustration */}
        <div className="relative flex items-center justify-center mt-4 md:mt-0">
          {/* Hero Image */}
          <Image 
            src="/images/hero.png" 
            alt="Tuition Rider Hero"
            width={500}
            height={400}
            className="rounded-lg"
            priority
          />
          
          {/* Expert Tutor Text Label */}
          <div className="absolute right-[10%] top-[50%]">
            <div className="relative">
              <div className="absolute -inset-1 rounded-lg bg-gradient-to-r from-blue-600 to-emerald-600 opacity-30 blur"></div>
              <div className="relative rounded-lg bg-white px-2 py-1 sm:px-6 sm:py-2">
                <p className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-xs sm:text-base font-semibold text-transparent">Expert Tutor</p>
              </div>
            </div>
          </div>
          
          {/* Student Text Label */}
          <div className="absolute left-[10%] top-[30%]">
            <div className="relative">
              <div className="absolute -inset-1 rounded-lg bg-gradient-to-r from-emerald-600 to-blue-600 opacity-30 blur"></div>
              <div className="relative rounded-lg bg-white px-2 py-1 sm:px-6 sm:py-2">
                <p className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-xs sm:text-base font-semibold text-transparent">Student</p>
              </div>
            </div>
          </div>
          
          {/* Small Decorative Elements */}
          <div className="absolute left-[40%] top-[20%] animate-bounce">
            <Star className="size-3 sm:size-4 md:size-6 text-yellow-400" />
          </div>
          <div className="absolute right-[30%] bottom-[20%] animate-bounce delay-100">
            <Star className="size-3 sm:size-4 md:size-6 text-emerald-400" />
          </div>
          
          {/* Floating Cards */}
          <Card className="group absolute top-[5%] -right-2 z-20 w-auto min-w-[120px] max-w-[180px] sm:min-w-44 sm:max-w-60 rounded-lg border border-white/20 bg-white/95 p-2 sm:p-3 md:p-4 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="relative shrink-0 rounded-full bg-gradient-to-br from-blue-100 to-emerald-100 p-1.5 sm:p-2">
                  <Target className="size-3 sm:size-4 md:size-5 text-blue-600" />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-600/10 to-emerald-600/10 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                </div>
                <p className="text-xs sm:text-sm font-semibold text-slate-800 transition-colors group-hover:text-blue-600">Limited Offer!</p>
              </div>
              <Button 
                size="sm" 
                className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 text-white shadow-lg transition-all hover:scale-105 hover:from-blue-700 hover:to-emerald-700 text-xs sm:text-sm group-hover:animate-pulse"
                onClick={() => window.location.href = '/contact'}
              >
                <div className="flex items-center justify-center gap-1 sm:gap-2">
                  <span>Contact Us</span>
                  <span>📧</span>
                </div>
              </Button>
            </div>
          </Card>

          <Card className="group absolute bottom-[-3%] left-[12%] z-20 w-auto min-w-[120px] max-w-[180px] sm:min-w-44 sm:max-w-60 rounded-lg border border-white/20 bg-white/95 p-2 sm:p-3 md:p-4 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="relative shrink-0 rounded-full bg-gradient-to-br from-emerald-100 to-blue-100 p-1.5 sm:p-2">
                <div className="relative size-3 sm:size-4 md:size-5">
                  <div className="absolute inset-0 animate-spin">
                    <div className="h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full bg-emerald-600" style={{ transform: 'translate(10%, 10%)' }} />
                  </div>
                  <svg className="size-full text-emerald-600 transition-colors duration-300 group-hover:text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-emerald-600/10 to-blue-600/10 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <p className="truncate text-xs sm:text-sm font-semibold text-slate-800 transition-colors group-hover:text-emerald-600">Shape Your Child&apos;s Future Today</p>
                  <span className="animate-bounce text-xs sm:text-sm">🎉</span>
                </div>
                <p className="mt-0.5 truncate text-[10px] sm:text-xs text-slate-600">20% off first month</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Curved border overlay */}
      <div className="absolute inset-x-0 bottom-0 z-10">
        <svg className="w-full text-white" style={{ height: '150px' }} viewBox="0 0 1440 150" fill="currentColor" preserveAspectRatio="none">
          <path d="M0,96L1440,32L1440,150L0,150Z" fillOpacity="1"></path>
        </svg>
      </div>
    </div>
  )
};