"use client"

import * as React from "react";
import { motion } from "framer-motion"
import { 
  BookOpen, 
  Calculator, 
  TestTube, 
  Globe, 
  History, 
  Languages, 
  Lightbulb, 
  Microscope, 
  Music, 
  Palette, 
  PenTool, 
  Scale, 
  ScrollText, 
  Shapes, 
  Sparkles, 
  Square, 
  Triangle, 
  Users,
  GraduationCap,
  Target
} from "lucide-react"
import MaxWidthWrapper from "@/app/components/shared/max-width-wrapper"

interface CategoryCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  items: string[];
}

interface SubjectGridProps {}

function CategoryCard({ title = "", description = "", icon, items = [] }: CategoryCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-2xl bg-white p-6 shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-emerald-50 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <div className="relative">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-gradient-to-br from-blue-100 to-emerald-100 p-2 text-blue-600">
              {icon}
            </div>
            <h3 className="text-xl font-semibold text-slate-800">{title}</h3>
          </div>
          <div className="rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-600">
            {items.length} subjects
          </div>
        </div>
        <p className="mb-6 text-slate-600">{description}</p>
        <div className="grid grid-cols-2 gap-3">
          {items.map((item, index) => (
            <div
              key={index}
              className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-700"
            >
              <div className="size-1.5 rounded-full bg-blue-600" />
              {item}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export const SubjectGrid: React.FC<SubjectGridProps> = () => {
  const categories = [
    {
      title: "Classes",
      description: "Comprehensive tutoring for all academic levels",
      icon: <GraduationCap className="h-5 w-5" />,
      items: ["Primary", "Secondary", "Junior College", "University"]
    },
    {
      title: "Subjects",
      description: "Expert guidance across various subjects",
      icon: <BookOpen className="h-5 w-5" />,
      items: ["Mathematics", "Science", "Languages", "Humanities"]
    },
    {
      title: "Exam Preparation",
      description: "Structured preparation for various examinations",
      icon: <Target className="h-5 w-5" />,
      items: ["Board Exams", "Entrance Tests", "Competitive Exams"]
    },
    {
      title: "Special Programs",
      description: "Customized learning programs for specific needs",
      icon: <Sparkles className="h-5 w-5" />,
      items: ["Remedial Classes", "Advanced Topics", "Skill Development"]
    }
  ]

  return (
    <section className="relative w-full overflow-hidden bg-gradient-to-b from-blue-50 via-white to-emerald-50/30 py-16">
      <MaxWidthWrapper>
        <div className="mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="relative mb-12 text-center"
          >
            <div className="absolute -top-8 left-1/2 -translate-x-1/2">
              <div className="relative">
                <Sparkles className="h-8 w-8 text-yellow-400 animate-bounce" />
                <div className="absolute top-0 left-0 h-full w-full bg-yellow-400/20 blur-xl animate-pulse" />
              </div>
            </div>
            <h2 className="mb-4 bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-3xl font-bold text-transparent md:text-4xl lg:text-5xl">
              Our Tutoring Programs
            </h2>
            <p className="text-lg text-slate-600 md:text-xl">
              Comprehensive learning solutions for every student
            </p>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2">
            {categories.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <CategoryCard {...category} />
              </motion.div>
            ))}
          </div>
        </div>
      </MaxWidthWrapper>
    </section>
  )
}

SubjectGrid.displayName = "SubjectGrid"