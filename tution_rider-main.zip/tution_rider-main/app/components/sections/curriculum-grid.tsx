"use client"

import * as React from "react";
import { motion } from "framer-motion"
import MaxWidthWrapper from "@/app/components/shared/max-width-wrapper"
import { BookOpen, GraduationCap, Award, FileText, Calculator, Globe, Atom, PenTool } from "lucide-react"

interface CurriculumItem {
  name: string;
  description: string;
  topics?: string[];
}

interface CurriculumCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  items: CurriculumItem[];
}

function CurriculumCard({ title = "", description = "", icon, items = [] }: CurriculumCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-2xl bg-white p-6 shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-emerald-50 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <div className="relative">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-gradient-to-br from-blue-100 to-emerald-100 p-2 text-blue-600">
              {icon}
            </div>
            <h3 className="text-xl font-semibold text-slate-800">{title}</h3>
          </div>
          <div className="rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-600">
            {items.length} subjects
          </div>
        </div>
        <p className="mb-6 text-slate-600">{description}</p>
        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={index} className="rounded-lg bg-slate-50 p-3">
              <div className="flex items-center gap-2 mb-2">
                <div className="size-1.5 rounded-full bg-blue-600" />
                <h4 className="font-medium text-slate-800">{item.name}</h4>
              </div>
              <p className="text-sm text-slate-600 mb-2">{item.description}</p>
              {item.topics && item.topics.length > 0 && (
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {item.topics.map((topic, topicIndex) => (
                    <div
                      key={topicIndex}
                      className="flex items-center gap-1 text-xs text-slate-700 bg-white px-2 py-1 rounded border border-slate-100"
                    >
                      <div className="size-1 rounded-full bg-emerald-500" />
                      {topic}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export interface CurriculumGridProps {
  className?: string;
}

export function CurriculumGrid({ className = "" }: CurriculumGridProps) {
  const curriculumCategories = [
    {
      title: "CBSE Curriculum",
      description: "Comprehensive coverage of Central Board of Secondary Education syllabus",
      icon: <BookOpen className="h-6 w-6" />,
      items: [
        { 
          name: "Mathematics", 
          description: "Develop strong mathematical foundations and problem-solving skills",
          topics: ["Algebra", "Geometry", "Arithmetic", "Statistics", "Trigonometry", "Calculus"]
        },
        { 
          name: "Science", 
          description: "Explore scientific concepts through theory and practical applications",
          topics: ["Physics", "Chemistry", "Biology", "Environmental Science"]
        },
        { 
          name: "English", 
          description: "Enhance language proficiency, comprehension, and writing skills",
          topics: ["Grammar", "Literature", "Writing", "Reading Comprehension"]
        },
        { 
          name: "Social Studies", 
          description: "Understand history, geography, civics, and economics",
          topics: ["History", "Geography", "Civics", "Economics"]
        }
      ]
    },
    {
      title: "ICSE Curriculum",
      description: "Detailed coverage of Indian Certificate of Secondary Education syllabus",
      icon: <GraduationCap className="h-6 w-6" />,
      items: [
        { 
          name: "Mathematics", 
          description: "Comprehensive mathematics with emphasis on applications",
          topics: ["Commercial Mathematics", "Algebra", "Geometry", "Mensuration", "Statistics"]
        },
        { 
          name: "Science", 
          description: "In-depth scientific knowledge with practical experiments",
          topics: ["Physics", "Chemistry", "Biology", "Scientific Reasoning"]
        },
        { 
          name: "English", 
          description: "Strong focus on literature and language skills",
          topics: ["Literature", "Grammar", "Creative Writing", "Comprehension"]
        },
        { 
          name: "History & Civics", 
          description: "Detailed study of Indian and world history with civics",
          topics: ["Indian History", "World History", "Civics", "Government"]
        }
      ]
    },
    {
      title: "State Board Curriculum",
      description: "Tailored tutoring for various state board syllabi",
      icon: <FileText className="h-6 w-6" />,
      items: [
        { 
          name: "Punjab State Board", 
          description: "Complete coverage of Punjab School Education Board syllabus",
          topics: ["All Subjects", "Punjabi Language", "Local History", "State Curriculum"]
        },
        { 
          name: "Other State Boards", 
          description: "Adaptable tutoring for various state education boards",
          topics: ["Customized Learning", "Board-Specific Content", "Exam Preparation"]
        }
      ]
    },
    {
      title: "Competitive Exam Preparation",
      description: "Specialized coaching for various competitive examinations",
      icon: <Award className="h-6 w-6" />,
      items: [
        { 
          name: "Olympiads", 
          description: "Preparation for national and international Olympiads",
          topics: ["Math Olympiad", "Science Olympiad", "English Olympiad", "Reasoning"]
        },
        { 
          name: "Scholarship Exams", 
          description: "Coaching for various scholarship examinations",
          topics: ["NTSE", "KVPY", "Other Scholarships"]
        },
        { 
          name: "Entrance Exams", 
          description: "Foundation for various entrance examinations",
          topics: ["JEE Foundation", "NEET Foundation", "Aptitude Building"]
        }
      ]
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  }

  return (
    <div className="bg-gradient-to-br from-blue-50 via-white to-emerald-50 py-16">
      <MaxWidthWrapper>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
          >
          <h1 className="mb-3 text-3xl font-bold lg:text-4xl">
            <span className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Our Curriculum Coverage
            </span>
          </h1>
          <p className="mx-auto mb-6 max-w-2xl text-slate-600">
            Comprehensive tutoring across various educational boards and competitive examinations
          </p>
          <div className="mx-auto h-1 w-32 rounded-full bg-gradient-to-r from-blue-600 to-emerald-600 lg:w-40"></div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mx-auto grid max-w-[1200px] grid-cols-1 gap-8 md:grid-cols-2 lg:gap-10"
        >
          {curriculumCategories.map((category, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
            >
              <CurriculumCard {...category} />
            </motion.div>
          ))}
        </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-16 rounded-xl bg-white p-6 shadow-lg"
        >
          <h2 className="mb-4 text-center text-2xl font-bold text-slate-800">
            <span className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Additional Academic Support
                    </span>
          </h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-4">
            {[
              { 
                icon: <Calculator className="h-6 w-6 text-blue-600" />, 
                title: "Homework Help", 
                description: "Assistance with daily assignments and homework" 
              },
              { 
                icon: <PenTool className="h-6 w-6 text-emerald-600" />, 
                title: "Project Guidance", 
                description: "Support for academic projects and presentations" 
              },
              { 
                icon: <Atom className="h-6 w-6 text-blue-600" />, 
                title: "Concept Clarification", 
                description: "In-depth explanation of difficult concepts" 
              },
              { 
                icon: <Globe className="h-6 w-6 text-emerald-600" />, 
                title: "Exam Preparation", 
                description: "Targeted preparation for all types of exams" 
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
                className="group rounded-lg border border-slate-100 bg-white p-4 shadow-sm transition-all duration-300 hover:shadow-md"
              >
                <div className="mb-3 flex size-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-50 to-emerald-50 transition-transform duration-300 group-hover:scale-110">
                  {item.icon}
                </div>
                <h3 className="mb-2 text-lg font-semibold text-slate-800">{item.title}</h3>
                <p className="text-sm text-slate-600">{item.description}</p>
              </motion.div>
            ))}
                </div>
              </motion.div>
      </MaxWidthWrapper>
      </div>
  )
}