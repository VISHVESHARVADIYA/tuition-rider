"use client"

import React from 'react'
import { motion } from 'framer-motion'
import { CalendarClock } from 'lucide-react'
import Container from '@/app/components/shared/container'

interface ComingSoonProps {
  title: string
  description: string
}

export function ComingSoon({ title, description }: ComingSoonProps) {
  return (
    <section className="py-20 md:py-32">
      <Container>
        <div className="flex flex-col items-center justify-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="relative mb-8"
          >
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600/20 to-emerald-600/20 blur-xl" />
            <div className="relative bg-white rounded-full p-5 shadow-md">
              <CalendarClock className="h-12 w-12 text-blue-600" />
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent"
          >
            {title}
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-gray-600 max-w-2xl mb-8"
          >
            {description}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="w-full max-w-md"
          >
            <div className="bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg p-6 border border-blue-100 shadow-sm">
              <h3 className="font-semibold text-gray-800 mb-2">
                Want to be notified when we launch?
              </h3>
              <div className="flex mt-4">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-4 py-2 rounded-r-md hover:from-blue-700 hover:to-emerald-700 transition-colors">
                  Notify Me
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                We&apos;ll notify you when new content is available. No spam, we promise!
              </p>
            </div>
          </motion.div>
        </div>
      </Container>
    </section>
  )
}