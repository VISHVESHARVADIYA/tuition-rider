'use client'

import { Star } from 'lucide-react'
import { useEffect, useState } from 'react'

interface FloatingStarsProps {
  count?: number
}

export function FloatingStars({ count = 5 }: FloatingStarsProps) {
  const [stars, setStars] = useState<Array<{
    id: number
    top: number
    left: number
    duration: number
  }>>([])

  // Generate random positions on the client side only
  useEffect(() => {
    const newStars = Array.from({ length: count }).map((_, i) => ({
      id: i,
      top: Math.random() * 100,
      left: Math.random() * 100,
      duration: 3 + Math.random() * 2
    }))
    setStars(newStars)
  }, [count])

  return (
    <>
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute animate-float"
          style={{
            top: `${star.top}%`,
            left: `${star.left}%`,
            animationDelay: `${star.id * 0.5}s`,
            animationDuration: `${star.duration}s`
          }}
        >
          <Star className="h-3 w-3 text-yellow-400 opacity-50" />
        </div>
      ))}
    </>
  )
}