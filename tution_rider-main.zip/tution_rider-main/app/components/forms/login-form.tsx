'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface LoginFormProps {
  type: 'user' | 'admin';
}

export function LoginForm({ type }: LoginFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
    regNo: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Check for empty fields
      if (type === 'admin' && !formData.regNo) {
        throw new Error('Registration number is required');
      }
      
      if (type === 'user' && !formData.email) {
        throw new Error('Email is required');
      }
      
      if (!formData.password) {
        throw new Error('Password is required');
      }

      const response = await fetch(`/api/auth/${type}-login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(type === 'admin' ? 
          { regNo: formData.regNo, password: formData.password } : 
          { email: formData.email, password: formData.password }),
      });

      // Check if the response is JSON
      const contentType = response.headers.get('content-type');
      let data;
      
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        // If not JSON, get text and create an error object
        const text = await response.text();
        console.error('Non-JSON response:', text);
        throw new Error('Server returned an invalid response');
      }

      if (!response.ok) {
        throw new Error(data?.error || 'Authentication failed');
      }

      toast.success('Login successful');
      router.push(type === 'admin' ? '/admin' : '/');
    } catch (err: any) {
      console.error('Login error:', err);
      toast.error('Login failed', {
        description: err.message || 'Invalid credentials or server error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {type === 'admin' ? (
        <div className="space-y-2">
          <label htmlFor="regNo" className="text-sm font-medium text-slate-700">
            Registration Number
          </label>
          <Input
            id="regNo"
            name="regNo"
            type="text"
            required
            placeholder="Enter your registration number"
            value={formData.regNo}
            onChange={(e) => setFormData({ ...formData, regNo: e.target.value })}
            className="w-full bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      ) : (
        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium text-slate-700">
            Email
          </label>
          <Input
            id="email"
            name="email"
            type="email"
            required
            placeholder="Enter your email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      )}
      <div className="space-y-2">
        <label htmlFor="password" className="text-sm font-medium text-slate-700">
          Password
        </label>
        <Input
          id="password"
          type="password"
          required
          placeholder="Enter your password"
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          className="w-full bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
        />
      </div>
      <Button
        type="submit"
        className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white font-medium"
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Signing in...
          </div>
        ) : (
          'Sign in'
        )}
      </Button>
      
      <div className="text-center">
        <a 
          href={type === 'admin' ? '/auth/login' : '/auth/admin/login'} 
          className="text-sm text-blue-600 hover:text-blue-500 hover:underline"
        >
          {type === 'admin' ? 'Switch to User Login' : 'Switch to Admin Login'}
        </a>
      </div>
    </form>
  );
} 