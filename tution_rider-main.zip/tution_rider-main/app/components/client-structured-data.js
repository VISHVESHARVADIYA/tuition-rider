'use client';

import { useEffect } from 'react';
import { siteConfig } from '@/config/site';

export default function ClientStructuredData() {
  useEffect(() => {
    // Organization data
    const organizationData = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Tuition Rider',
      url: siteConfig.url,
      logo: `${siteConfig.url}/logo.png`,
      sameAs: [
        siteConfig.links.twitter,
        siteConfig.links.instagram,
        siteConfig.links.facebook,
        siteConfig.links.linkedin
      ],
      contactPoint: [
        {
          '@type': 'ContactPoint',
          telephone: '+91-8800-8800-88',
          contactType: 'customer service',
          availableLanguage: ['English', 'Hindi'],
          areaServed: 'IN'
        }
      ],
      address: {
        '@type': 'PostalAddress',
        addressCountry: 'India',
        addressRegion: 'Delhi NCR'
      }
    };

    // Website data
    const websiteData = {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'Tuition Rider - Professional Home Tutoring',
      url: siteConfig.url,
      potentialAction: {
        '@type': 'SearchAction',
        target: {
          '@type': 'EntryPoint',
          urlTemplate: `${siteConfig.url}/search?q={search_term_string}`
        },
        'query-input': 'required name=search_term_string'
      }
    };

    // Site navigation
    const navigationData = {
      '@context': 'https://schema.org',
      '@type': 'SiteNavigationElement',
      name: [
        'Find a Tutor',
        'Become a Tutor',
        'How it Works',
        'Resources',
        'About Us',
        'Contact'
      ],
      url: [
        `${siteConfig.url}/tutors`,
        `${siteConfig.url}/become-tutor`,
        `${siteConfig.url}/how-it-works`,
        `${siteConfig.url}/resources`,
        `${siteConfig.url}/about`,
        `${siteConfig.url}/contact`
      ]
    };

    // Create and append the scripts
    const structuredDataElements = [organizationData, websiteData, navigationData];
    
    structuredDataElements.forEach(data => {
      // Check if script already exists to prevent duplicates
      const scriptId = `structured-data-${data['@type']}`;
      if (!document.getElementById(scriptId)) {
        const script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';
        script.innerHTML = JSON.stringify(data);
        document.head.appendChild(script);
      }
    });

    return () => {
      // Clean up function if component unmounts
      structuredDataElements.forEach(data => {
        const scriptId = `structured-data-${data['@type']}`;
        const script = document.getElementById(scriptId);
        if (script) {
          document.head.removeChild(script);
        }
      });
    };
  }, []);

  return null;
} 