'use client';

import { useEffect } from 'react';

export default function HeadMeta() {
  useEffect(() => {
    // Create favicon link elements if they don't exist
    const faviconLinks = [
      { rel: 'apple-touch-icon', sizes: '180x180', href: '/apple-touch-icon.png' },
      { rel: 'icon', type: 'image/png', sizes: '32x32', href: '/favicon-32x32.png' },
      { rel: 'icon', type: 'image/png', sizes: '16x16', href: '/favicon-16x16.png' },
      { rel: 'manifest', href: '/site.webmanifest' },
      { rel: 'mask-icon', href: '/safari-pinned-tab.svg', color: '#4f46e5' }
    ];

    const metaTags = [
      { name: 'msapplication-TileColor', content: '#4f46e5' },
      { name: 'theme-color', content: '#4f46e5' }
    ];

    // Add favicon links
    faviconLinks.forEach(link => {
      if (!document.querySelector(`link[rel="${link.rel}"][href="${link.href}"]`)) {
        const linkElement = document.createElement('link');
        Object.keys(link).forEach(attr => {
          linkElement.setAttribute(attr, link[attr]);
        });
        document.head.appendChild(linkElement);
      }
    });

    // Add meta tags
    metaTags.forEach(meta => {
      if (!document.querySelector(`meta[name="${meta.name}"]`)) {
        const metaElement = document.createElement('meta');
        Object.keys(meta).forEach(attr => {
          metaElement.setAttribute(attr, meta[attr]);
        });
        document.head.appendChild(metaElement);
      }
    });

    return () => {
      // Clean up function - optional, as these elements generally persist
    };
  }, []);

  return null;
} 