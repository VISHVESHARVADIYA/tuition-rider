'use client'

import { useEffect, useState } from 'react'

interface DebugIndicatorProps {
  isMobileMenuOpen: boolean;
  isMenuClickable: boolean;
}

export function DebugIndicator({ isMobileMenuOpen, isMenuClickable }: DebugIndicatorProps) {
  const [isMounted, setIsMounted] = useState(false)
  
  useEffect(() => {
    setIsMounted(true)
  }, [])
  
  if (!isMounted || process.env.NODE_ENV !== 'development') {
    return null
  }
  
  return (
    <div className="fixed top-0 right-0 bg-black text-white text-xs p-1 z-[9999]">
      Mobile Menu: {isMobileMenuOpen ? 'OPEN' : 'CLOSED'} | Clickable: {isMenuClickable ? 'YES' : 'NO'}
    </div>
  )
}