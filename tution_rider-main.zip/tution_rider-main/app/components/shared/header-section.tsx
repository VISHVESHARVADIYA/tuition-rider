import * as React from "react";
import { cn } from '@/lib/utils';

interface HeaderSectionProps {
  label?: string;
  title: string;
  subtitle?: string;
  centered?: boolean;
  className?: string;
}

export const HeaderSection: React.FC<HeaderSectionProps> = ({
  label,
  title,
  subtitle,
  centered = false,
  className
}) => {
  return (
    <div className={cn(
      'space-y-4',
      centered && 'text-center',
      className
    )}>
      {label && (
        <div className="text-gradient_indigo-purple mb-4 font-semibold">
          {label}
        </div>
      )}
      <h2 className={cn(
        'text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl',
        centered ? 'mx-auto max-w-[800px]' : ''
      )}>
        {title}
      </h2>
      {subtitle && (
        <p className={cn(
          'text-muted-foreground text-lg sm:text-xl',
          centered ? 'mx-auto max-w-[700px]' : ''
        )}>
          {subtitle}
        </p>
      )}
    </div>
  );
};

HeaderSection.displayName = "HeaderSection";