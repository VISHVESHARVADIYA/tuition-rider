"use client";

import * as React from "react";

import Link from "next/link";

export 
interface SidebarProps {
  className?: string;
}

function Sidebar({ className }: SidebarProps = {}) {
  return (
    <div className="w-64 bg-gray-100 min-h-screen p-4">
      <div className="text-xl font-bold mb-6">Tuition Rider</div>
      <nav className="space-y-2">
        <Link href="/dashboard" className="block p-2 hover:bg-gray-200 rounded">
          Dashboard
        </Link>
        <Link href="/resources" className="block p-2 hover:bg-gray-200 rounded">
          Resources
        </Link>
        <Link href="/dashboard/bookings" className="block p-2 hover:bg-gray-200 rounded">
          Bookings
        </Link>
        <Link href="/dashboard/profile" className="block p-2 hover:bg-gray-200 rounded">
          Profile
        </Link>
      </nav>
    </div>
  );
};