import * as React from "react";
import Image from "next/image";

interface LogoProps {
  className?: string;
  onClick?: () => void;
}

export function Logo({ className = "", onClick }: LogoProps) {
  return (
    <div className={`flex items-center ${className}`} onClick={onClick}>
      <Image 
        src="/logo192.png" 
        alt="Tuition Rider Logo" 
        width={40} 
        height={40}
        className="object-contain"
      />
    </div>
  )
}