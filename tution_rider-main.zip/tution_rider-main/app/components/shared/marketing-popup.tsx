"use client"

import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/app/components/ui/dialog'
import { Button } from '@/app/components/ui/button'
import { Card } from '@/app/components/ui/card'
import { Check, Star, GraduationCap, Clock, ArrowRight, Sparkles } from 'lucide-react'
import { motion } from 'framer-motion'

export function MarketingPopup() {
  const [isOpen, setIsOpen] = useState<boolean>(false)
  const [currentStep, setCurrentStep] = useState<number>(1)
  const [isMounted, setIsMounted] = useState<boolean>(false)
  const totalSteps = 3

  useEffect(() => {
    setIsMounted(true)

    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 5000)

    return () => clearTimeout(timer)
  }, [])

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    } else {
      setIsOpen(false)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  // Don't render anything until client-side hydration is complete
  if (!isMounted) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[550px] p-0 overflow-hidden border-0 shadow-2xl w-[95%] max-h-[85vh] overflow-y-hidden">
        {/* Hidden description for accessibility */}
        <DialogDescription className="sr-only">
          Marketing popup with special offers and information
        </DialogDescription>

        {/* Background gradient elements */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl" />

        <div className="relative z-10 p-3 sm:p-6 overflow-y-auto max-h-[75vh]">
          {/* Progress indicator */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gray-100">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-600 to-emerald-600"
              initial={{ width: `${((currentStep - 1) / totalSteps) * 100}%` }}
              animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {/* Step 1: Welcome */}
          {currentStep === 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <DialogHeader className="mb-4 sm:mb-6">
                <div className="flex items-center justify-center mb-3 sm:mb-4">
                  <div className="relative">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600 to-emerald-600 blur-sm animate-pulse" />
                    <div className="relative bg-white rounded-full p-2 sm:p-3">
                      <GraduationCap className="h-6 w-6 sm:h-8 sm:w-8 text-blue-600" />
                    </div>
                  </div>
                </div>
                <DialogTitle className="text-xl sm:text-2xl text-center font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
                  Welcome to Tuition Rider!
                </DialogTitle>
                <p className="text-center text-gray-500 mt-1 sm:mt-2 text-sm sm:text-base">Your child&apos;s academic journey starts here</p>
              </DialogHeader>

              <div className="space-y-3 sm:space-y-6 py-2 sm:py-4">
                <div className="bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg p-2 sm:p-4 border border-blue-100">
                  <h3 className="font-semibold text-gray-800 mb-1 sm:mb-2 flex items-center text-sm sm:text-base">
                    <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600 mr-1.5 sm:mr-2 flex-shrink-0" />
                    Limited Time Offer!
                  </h3>
                  <p className="text-gray-600 text-xs sm:text-sm">
                    Sign up today and receive <span className="font-bold text-emerald-600">20% OFF</span> your first month of tutoring!
                  </p>
                  <div className="flex items-center mt-1.5 sm:mt-2 text-xs sm:text-sm text-gray-500">
                    <Clock className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
                    <span>Offer expires soon</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
                  <Card className="p-2 sm:p-3 hover:shadow-md transition-shadow">
                    <div className="flex items-start">
                      <div className="bg-blue-100 rounded-full p-1.5 sm:p-2 mr-2 sm:mr-3 flex-shrink-0">
                        <Check className="h-3 w-3 sm:h-4 sm:w-4 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-xs sm:text-sm">Personalized Learning</h4>
                        <p className="text-[10px] sm:text-xs text-gray-500">Tailored to your child&apos;s needs</p>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-2 sm:p-3 hover:shadow-md transition-shadow">
                    <div className="flex items-start">
                      <div className="bg-emerald-100 rounded-full p-1.5 sm:p-2 mr-2 sm:mr-3 flex-shrink-0">
                        <Check className="h-3 w-3 sm:h-4 sm:w-4 text-emerald-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-xs sm:text-sm">Expert Tutors</h4>
                        <p className="text-[10px] sm:text-xs text-gray-500">Qualified and experienced</p>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 2: Success Stories */}
          {currentStep === 2 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <DialogHeader className="mb-3 sm:mb-6">
                <DialogTitle className="text-xl sm:text-2xl text-center font-bold">
                  Our Success Stories
                </DialogTitle>
                <p className="text-center text-gray-500 mt-1 sm:mt-2 text-sm sm:text-base">Join hundreds of satisfied students</p>
              </DialogHeader>

              <div className="space-y-3 sm:space-y-6 py-2 sm:py-4">
                <div className="grid grid-cols-3 gap-1 sm:gap-3 text-center">
                  <div className="bg-blue-50 rounded-lg p-2 sm:p-3">
                    <p className="text-lg sm:text-2xl font-bold text-blue-600">95%</p>
                    <p className="text-[10px] sm:text-xs text-gray-600">Pass Rate</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-2 sm:p-3">
                    <p className="text-lg sm:text-2xl font-bold text-emerald-600">85%</p>
                    <p className="text-[10px] sm:text-xs text-gray-600">A+ Grades</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-2 sm:p-3">
                    <p className="text-lg sm:text-2xl font-bold text-purple-600">100%</p>
                    <p className="text-[10px] sm:text-xs text-gray-600">Satisfaction</p>
                  </div>
                </div>

                <Card className="p-3 sm:p-4 border-l-4 border-l-blue-500">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mr-2 sm:mr-3">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-3 w-3 sm:h-4 sm:w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-xs sm:text-sm italic text-gray-600">
                        &quot;My son&apos;s grades improved dramatically after just 2 months with Tuition Rider. The personalized approach made all the difference!&quot;
                      </p>
                      <p className="text-[10px] sm:text-xs font-medium text-gray-800 mt-1 sm:mt-2">— Sarah Johnson, Parent</p>
                    </div>
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {/* Step 3: Call to Action */}
          {currentStep === 3 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <DialogHeader className="mb-3 sm:mb-6">
                <DialogTitle className="text-xl sm:text-2xl text-center font-bold">
                  Ready to Get Started?
                </DialogTitle>
                <p className="text-center text-gray-500 mt-1 sm:mt-2 text-sm sm:text-base">Take the first step toward academic excellence</p>
              </DialogHeader>

              <div className="space-y-3 sm:space-y-6 py-2 sm:py-4">
                <div className="bg-gradient-to-r from-blue-600 to-emerald-600 rounded-lg p-3 sm:p-6 text-white">
                  <h3 className="font-bold text-lg sm:text-xl mb-1 sm:mb-2">Special Offer</h3>
                  <p className="mb-2 sm:mb-4 text-sm sm:text-base">Sign up today and receive:</p>
                  <ul className="space-y-1 sm:space-y-2 mb-3 sm:mb-4 text-sm sm:text-base">
                    <li className="flex items-start">
                      <Check className="h-4 w-4 sm:h-5 sm:w-5 mr-1.5 sm:mr-2 flex-shrink-0" />
                      <span>20% OFF your first month</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-4 w-4 sm:h-5 sm:w-5 mr-1.5 sm:mr-2 flex-shrink-0" />
                      <span>Free assessment session</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-4 w-4 sm:h-5 sm:w-5 mr-1.5 sm:mr-2 flex-shrink-0" />
                      <span>Personalized learning plan</span>
                    </li>
                  </ul>
                  <Button
                    className="w-full bg-white hover:bg-gray-100 text-blue-600 font-medium text-xs sm:text-sm py-1.5 sm:py-2 h-auto"
                    onClick={() => window.location.href = '/contact'}
                  >
                    Claim Your Offer
                    <ArrowRight className="ml-1.5 sm:ml-2 h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Navigation buttons */}
          <div className="flex justify-between mt-3 sm:mt-6">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 1}
              className={`${currentStep === 1 ? "opacity-0" : ""} text-xs sm:text-sm py-1 sm:py-2 h-8 sm:h-10`}
              size="sm"
            >
              Previous
            </Button>
            <div className="flex space-x-1 items-center">
              {Array.from({ length: totalSteps }).map((_, index) => (
                <div
                  key={index}
                  className={`h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full ${
                    currentStep > index
                      ? "bg-blue-600"
                      : currentStep === index + 1
                        ? "bg-blue-300"
                        : "bg-gray-200"
                  }`}
                />
              ))}
            </div>
            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white hover:from-blue-700 hover:to-emerald-700 text-xs sm:text-sm py-1 sm:py-2 h-8 sm:h-10"
              size="sm"
            >
              {currentStep < totalSteps ? "Next" : "Get Started"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}