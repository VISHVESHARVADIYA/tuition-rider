// This file helps with handling the special (marketing) directory
// for Vercel deployments where parentheses in directory names can cause issues

export default function marketingRouteHandler(path) {
  // This is a helper function that can be used to resolve
  // marketing routes in your application
  return `/marketing${path}`;
}

// Export the list of common marketing routes
export const marketingRoutes = [
  '/',
  '/about',
  '/blog',
  '/contact',
  '/courses',
  '/curriculum',
  '/faq',
  '/privacy-policy',
  '/resources',
  '/reviews',
  '/services',
  '/terms',
];

// This function can be used to check if a path is a marketing route
export function isMarketingRoute(path) {
  return marketingRoutes.includes(path);
} 