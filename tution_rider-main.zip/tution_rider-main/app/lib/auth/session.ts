import { cookies } from "next/headers";
import { getServerSession } from "next-auth";
import { authOptions } from "./auth-options";
import { AuthError } from "@/types/auth";
import { env } from '@/env.mjs';
import { IronSessionOptions } from "iron-session";

const SESSION_COOKIE_NAME = "next-auth.session-token";
const SESSION_DURATION = 30 * 24 * 60 * 60; // 30 days in seconds

export async function getSession() {
  return await getServerSession(authOptions);
}

export async function getCurrentUser() {
  const session = await getSession();
  return session?.user;
}

export async function validateSession() {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get(SESSION_COOKIE_NAME);

    if (!sessionCookie?.value) {
      throw new AuthError("UNAUTHORIZED", "No session token found");
    }

    const session = await getSession();

    if (!session) {
      throw new AuthError("UNAUTHORIZED", "Invalid session");
    }

    return session;
  } catch (error) {
    if (error instanceof AuthError) {
      throw error;
    }
    throw new AuthError("UNAUTHORIZED", "Session validation failed");
  }
}

export async function getSessionToken() {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get(SESSION_COOKIE_NAME);
  return sessionCookie?.value;
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE_NAME);
}

export async function refreshSession(oldToken: string, newToken: string) {
  try {
    const cookieStore = await cookies();
    cookieStore.delete(SESSION_COOKIE_NAME);
    cookieStore.set(SESSION_COOKIE_NAME, newToken, {
      httpOnly: true,
      secure: env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: SESSION_DURATION
    });
  } catch (error) {
    throw new AuthError("SERVER_ERROR", "Failed to refresh session");
  }
}

export const sessionOptions: IronSessionOptions = {
  password: {
    // ... existing code ...
  },
  cookieName: "iron-session",
  cookieOptions: {
    secure: env.NODE_ENV === "production",
  },
};