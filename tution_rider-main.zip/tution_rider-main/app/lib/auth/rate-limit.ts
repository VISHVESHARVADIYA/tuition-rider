// Simple in-memory rate limiter storage
// For production, this should use Redis or a persistent database
const rateLimitStore: Record<string, { count: number; timestamp: number }> = {};

/**
 * Check if an operation is rate limited
 * @param key Unique identifier for the operation (e.g., 'login:user@example.com')
 * @param maxAttempts Maximum number of attempts allowed in the window
 * @param windowMs Time window in milliseconds
 * @returns True if rate limited, false otherwise
 */
export const rateLimit = async (
  key: string,
  maxAttempts: number = 5,
  windowMs: number = 15 * 60 * 1000
): Promise<boolean> => {
  const now = Date.now();
  const entry = rateLimitStore[key];

  // If no entry or expired, create new entry
  if (!entry || now - entry.timestamp > windowMs) {
    rateLimitStore[key] = { count: 1, timestamp: now };
    return false;
  }

  // Increment count and check against limit
  entry.count += 1;
  
  return entry.count > maxAttempts;
};

/**
 * Check rate limit status without incrementing
 */
export const checkRateLimit = async (
  key: string,
  maxAttempts: number = 5,
  windowMs: number = 15 * 60 * 1000
): Promise<{ limited: boolean; attemptsLeft: number }> => {
  const now = Date.now();
  const entry = rateLimitStore[key];

  if (!entry || now - entry.timestamp > windowMs) {
    return { limited: false, attemptsLeft: maxAttempts };
  }

  return { 
    limited: entry.count >= maxAttempts, 
    attemptsLeft: Math.max(0, maxAttempts - entry.count)
  };
};

/**
 * Reset rate limit for a key
 */
export const resetRateLimit = async (key: string): Promise<void> => {
  delete rateLimitStore[key];
};

/**
 * Increment failed attempts counter
 */
export const incrementFailedAttempts = async (
  key: string,
  windowMs: number = 15 * 60 * 1000
): Promise<number> => {
  const now = Date.now();
  const entry = rateLimitStore[key];

  if (!entry || now - entry.timestamp > windowMs) {
    rateLimitStore[key] = { count: 1, timestamp: now };
    return 1;
  }

  entry.count += 1;
  return entry.count;
}; 