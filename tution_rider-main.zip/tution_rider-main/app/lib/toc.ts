import { TableOfContents } from "@/types/toc";

export function getTableOfContents(markdown: string): TableOfContents {
  const headings = markdown.split('\n')
    .filter(line => /^#{1,6}\s+.+/.test(line))
    .map(line => {
      const level = line.match(/^(#{1,6})\s+/)?.[1].length || 1;
      const text = line.replace(/^#{1,6}\s+/, '');
      const id = text.toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)+/g, "");

      return { text, level, id };
    })[0] || { text: "", level: 1, id: "" };

  return headings;
}
