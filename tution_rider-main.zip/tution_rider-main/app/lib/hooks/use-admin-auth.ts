'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export function useAdminAuth() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const router = useRouter();

  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      // First check for the admin-auth cookie, which is faster
      const adminCookieStr = document.cookie
        .split('; ')
        .find(row => row.startsWith('admin-auth='));

      const adminCookieValue = adminCookieStr ? adminCookieStr.split('=')[1] : null;

      // If we have the admin cookie, we're done
      if (adminCookieValue === 'true') {
        setIsAdmin(true);
        setIsLoading(false);
        return;
      }
      
      // If no cookie, check the API
      const response = await fetch('/api/auth/admin-check');
      const data = await response.json();
      
      // If the API check passes, set a cookie for faster future checks
      if (response.ok && data.hasPermissions) {
        document.cookie = 'admin-auth=true; path=/; max-age=604800; SameSite=Lax';
        setIsAdmin(true);
      } else {
        setIsAdmin(false);
      }
    } catch (error) {
      console.error('Admin check error:', error);
      setIsAdmin(false);
      
      // In development, always allow admin access
      if (process.env.NODE_ENV === 'development') {
        document.cookie = 'admin-auth=true; path=/; max-age=604800; SameSite=Lax';
        setIsAdmin(true);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoggingOut(true);
    try {
      // Clear the admin cookie
      document.cookie = 'admin-auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
      
      // Call the logout API
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/');
    } finally {
      setIsLoggingOut(false);
    }
  };

  return { isAdmin, isLoading, logout, isLoggingOut };
}
