'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';

interface UserData {
  id?: string;
  email?: string;
  fullName?: string;
  full_name?: string;
  name?: string;
  role?: string;
  [key: string]: any;
}

export function useUserAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const router = useRouter();
  const supabase = createClientComponentClient();

  const recheckAuth = useCallback(async () => {
    try {
      setIsLoading(true);
      
      // Check authentication status
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData?.session;
      const isAuth = !!session;
      setIsAuthenticated(isAuth);
      
      // If authenticated, get user data
      if (isAuth && session?.user) {
        const userData = session.user;
        
        // Get additional user data from profiles table
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userData.id)
          .single();
          
        if (profileError && profileError.message) {
          // Only log if there's an actual error message
          // For 'No rows found' errors, we'll just use userData without profileData
          if (profileError.code !== 'PGRST116') {
            console.error('Error fetching profile data:', profileError.message);
          }
        }
        
        // Combine auth user data with profile data
        const fullUserData = {
          ...userData,
          ...(profileData || {}),
          fullName: profileData?.full_name || userData.user_metadata?.full_name || userData.email?.split('@')[0]
        };
        
        // Store the combined user data
        setUser(fullUserData);
        
        // Check if user is admin based on role from profile
        const userRole = profileData?.role || userData.user_metadata?.role;
        setIsAdmin(userRole === 'ADMIN');
        
        // Also check cookies for admin status (fallback)
        const hasAdminRole = typeof document !== 'undefined' && document.cookie.includes('user-role=ADMIN');
        if (hasAdminRole && !isAdmin) {
          setIsAdmin(true);
        }
        
        // Store user info in localStorage for persistent display
        if (typeof window !== 'undefined') {
          localStorage.setItem('userInfo', JSON.stringify({
            isAuthenticated: true,
            fullName: fullUserData.fullName,
            email: userData.email,
            isAdmin: userRole === 'ADMIN' || hasAdminRole
          }));
        }
      } else {
        // Clear user data if not authenticated
        setUser(null);
        setIsAdmin(false);
        
        // Clear local storage
        if (typeof window !== 'undefined') {
          localStorage.removeItem('userInfo');
        }
      }
    } catch (error) {
      console.error('Auth check error:', error instanceof Error ? error.message : 'Unknown error');
      setIsAuthenticated(false);
      setUser(null);
      setIsAdmin(false);
    } finally {
      setIsLoading(false);
    }
  }, [supabase, isAdmin]);

  // Initial authentication check
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Try to load from localStorage first for immediate display
      const storedUserInfo = localStorage.getItem('userInfo');
      if (storedUserInfo) {
        try {
          const parsedInfo = JSON.parse(storedUserInfo);
          // Make sure we have valid auth information before setting state
          if (parsedInfo && typeof parsedInfo === 'object') {
            setIsAuthenticated(parsedInfo.isAuthenticated || false);
            setIsAdmin(parsedInfo.isAdmin || false);
            setUser(prev => {
              const base = prev || {};
              return { 
                ...base, 
                fullName: parsedInfo.fullName, 
                email: parsedInfo.email 
              };
            });
          }
        } catch (e) {
          console.error('Error parsing stored user info:', e);
          // Clear corrupt data
          localStorage.removeItem('userInfo');
        }
      } else {
        // Ensure we're showing not authenticated if no stored info
        setIsAuthenticated(false);
      }
      
      // Then recheck auth from server
      recheckAuth();
      
      // Set up auth change listener
      const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
        recheckAuth();
      });
      
      return () => {
        subscription.unsubscribe();
      };
    }
  }, [recheckAuth, supabase.auth]);

  const logout = async () => {
    setIsLoggingOut(true);
    try {
      await supabase.auth.signOut();
      
      // Clear localStorage
      if (typeof window !== 'undefined') {
        localStorage.removeItem('userInfo');
      }
      
      setIsAuthenticated(false);
      setUser(null);
      setIsAdmin(false);
      
      router.push('/');
      router.refresh();
    } finally {
      setIsLoggingOut(false);
    }
  };

  return { 
    isAuthenticated, 
    isAdmin, 
    user, 
    isLoading, 
    isLoggingOut, 
    logout,
    recheckAuth
  };
} 