'use client'

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/app/lib/supabase/client"
import { Button } from "@/app/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/app/components/ui/card"
import { Input } from "@/app/components/ui/input"
import { Label } from "@/app/components/ui/label"
import { Separator } from "@/app/components/ui/separator"
import { toast } from "sonner"
import { AlertCircle, LockIcon, Loader2, Save, User, Shield } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert"

export default function SettingsPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const router = useRouter()

  // Check admin authentication
  useEffect(() => {
    const checkAdmin = async () => {
      // Only run in browser environment
      if (typeof window === 'undefined') return;

      // Get the admin-auth cookie directly
      const adminCookieStr = document.cookie
        .split('; ')
        .find(row => row.startsWith('admin-auth='));

      const adminCookieValue = adminCookieStr ? adminCookieStr.split('=')[1] : null;

      // Check if the admin-auth cookie is set to 'true'
      if (adminCookieValue === 'true') {
        // Admin is authenticated
        return;
      }

      // If no admin cookie, try to check through Supabase session
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session && session.user.email === 'tuitionrider1@gmail.com') {
          // Set the admin cookie since this is the admin email
          document.cookie = 'admin-auth=true; path=/; max-age=604800; SameSite=Lax';
          return;
        }
      } catch (error) {
        console.error('Error checking session:', error);
      }

      // If we get here, user is not authenticated as admin, redirect to login
      console.log('Not authenticated as admin, redirecting to login');
      router.push("/auth/admin/login");
    };

    checkAdmin();
  }, [router]);

  const handleUpdateProfile = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setIsSaving(true)

    try {
      const formData = new FormData(event.currentTarget)
      const updates = {
        full_name: formData.get('fullName'),
        phone: formData.get('phone'),
        updated_at: new Date().toISOString(),
      }

      const { error } = await supabase.auth.updateUser({ data: updates })

      if (error) throw error

      toast.success('Profile updated successfully')
    } catch (error) {
      console.error('Error updating profile:', error)
      toast.error('Failed to update profile')
    } finally {
      setIsSaving(false)
    }
  }

  const handleUpdatePassword = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setIsLoading(true)

    try {
      const formData = new FormData(event.currentTarget)
      const currentPassword = formData.get('currentPassword') as string
      const newPassword = formData.get('newPassword') as string
      const confirmPassword = formData.get('confirmPassword') as string

      if (newPassword !== confirmPassword) {
        toast.error('New passwords do not match')
        setIsLoading(false)
        return
      }

      const { error } = await supabase.auth.updateUser({ password: newPassword })

      if (error) throw error

      toast.success('Password updated successfully')
      
      // Reset form
      event.currentTarget.reset()
    } catch (error) {
      console.error('Error updating password:', error)
      toast.error('Failed to update password')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container px-4 py-6 md:py-10">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Admin Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Alert className="mb-6 bg-amber-50 border-amber-200">
        <AlertCircle className="h-4 w-4 text-amber-600" />
        <AlertTitle className="text-amber-800">Important Note</AlertTitle>
        <AlertDescription className="text-amber-700">
          Changes made here will affect the admin account. Please be careful when updating sensitive information.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Profile Settings */}
        <Card className="md:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              <CardTitle>Profile Information</CardTitle>
            </div>
            <CardDescription>
              Update your personal information
            </CardDescription>
          </CardHeader>
          
          <Separator />
          
          <CardContent className="pt-6">
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  placeholder="Enter your full name"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="Enter your phone number"
                />
              </div>

              <Button 
                type="submit" 
                disabled={isSaving} 
                className="w-full"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving Changes...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Profile
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Password Settings */}
        <Card className="md:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <LockIcon className="h-5 w-5 text-primary" />
              <CardTitle>Security Settings</CardTitle>
            </div>
            <CardDescription>
              Update your password and security preferences
            </CardDescription>
          </CardHeader>
          
          <Separator />
          
          <CardContent className="pt-6">
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <Input
                  id="currentPassword"
                  name="currentPassword"
                  type="password"
                  placeholder="••••••••"
                  required
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="newPassword">New Password</Label>
                <Input
                  id="newPassword"
                  name="newPassword"
                  type="password"
                  placeholder="••••••••"
                  required
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  required
                />
              </div>

              <Button 
                type="submit" 
                disabled={isLoading}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating Password...
                  </>
                ) : (
                  <>
                    <Shield className="mr-2 h-4 w-4" />
                    Update Password
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
} 