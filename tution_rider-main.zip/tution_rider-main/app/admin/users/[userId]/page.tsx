'use client';

import { Button } from '@/app/components/ui/button';
import { Card, CardContent } from '@/app/components/ui/card';
import { ArrowLeft, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/app/lib/supabase/client';
import { toast } from 'sonner';

// Demo user data in case of database connection issues
const demoUser = {
  id: "demo-user",
  full_name: "Demo Student",
  email: "demo.student@example.com",
  phone: "+91 98765 43210",
  grade: "Grade 10",
  subjects: ["Mathematics", "Physics", "Chemistry"],
  created_at: "2023-03-15T10:30:00Z",
  last_login: "2023-04-01T08:15:00Z"
};

export default function UserDetailPage({ params }: { params: { userId: string } }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState<any>(null);
  const [isDemoData, setIsDemoData] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check if admin is authenticated
    const checkAdmin = async () => {
      // Only run in browser environment
      if (typeof window === 'undefined') return;

      // Get the admin-auth cookie directly
      const adminCookieStr = document.cookie
        .split('; ')
        .find(row => row.startsWith('admin-auth='));

      const adminCookieValue = adminCookieStr ? adminCookieStr.split('=')[1] : null;

      // Check if the admin-auth cookie is set to 'true'
      if (adminCookieValue === 'true') {
        // Admin is authenticated, fetch user data
        fetchUserData();
        return;
      }

      // If no admin cookie, try to check through Supabase session
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session && session.user.email === 'tuitionrider1@gmail.com') {
          // Set the admin cookie since this is the admin email
          document.cookie = 'admin-auth=true; path=/; max-age=604800; SameSite=Lax';
          fetchUserData();
          return;
        }
      } catch (error) {
        console.error('Error checking session:', error);
      }

      // If we get here, user is not authenticated as admin, redirect to login
      console.log('Not authenticated as admin, redirecting to login');
      router.push('/auth/admin/login');
    };

    const fetchUserData = async () => {
      setLoading(true);
      setError(null);
      
      // If the ID starts with "demo-", use the demo data directly
      if (params.userId === 'placeholder' || params.userId.startsWith('demo-')) {
        setIsDemoData(true);
        setUserData({...demoUser, id: params.userId});
        setLoading(false);
        return;
      }

      try {
        // Try to get users from Supabase - using simple select without .single()
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', params.userId);
        
        // Check if we got an error
        if (error) {
          console.error("Error fetching user:", error);
          throw new Error(error.message || "Failed to fetch user");
        }
        
        // If we have data (array), use the first item
        if (data && Array.isArray(data) && data.length > 0) {
          setUserData(data[0]);
          setIsDemoData(false);
        } else {
          // If no data but also no error, use demo data
          console.warn(`No user data found for ID: ${params.userId}, using demo data`);
          setUserData({...demoUser, id: params.userId});
          setIsDemoData(true);
          toast.error("Couldn't find user data. Showing demo content instead.");
        }
      } catch (err: any) {
        // Handle errors and use demo data
        console.error("Error fetching user data:", err);
        setError(err.message || "Failed to fetch user data");
        setUserData({...demoUser, id: params.userId});
        setIsDemoData(true);
        toast.error("Failed to retrieve user data. Showing demo content instead.");
      } finally {
        setLoading(false);
      }
    };

    checkAdmin();
  }, [params.userId, router]);

  if (loading) {
    return (
      <div className="container px-4 py-6 md:py-10 flex items-center justify-center min-h-[70vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading user details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container px-4 py-6 md:py-10">
      <div className="flex items-center gap-2 mb-4 md:mb-8">
        <Link href="/admin/users">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl md:text-3xl font-bold">User Details</h1>
      </div>
      
      {isDemoData && (
        <Card className="mb-4 bg-amber-50 border-amber-200">
          <CardContent className="p-4 text-amber-800">
            <p className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 text-amber-600" />
              {error ? `Error: ${error}. ` : ''}
              Showing placeholder data as we couldn't retrieve the actual user information.
            </p>
          </CardContent>
        </Card>
      )}
      
      <Card className="overflow-hidden">
        <CardContent className="p-6">
          {userData ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">{userData.full_name || 'No Name'}</h2>
              <p><strong>Email:</strong> {userData.email || 'No Email'}</p>
              <p><strong>Phone:</strong> {userData.phone || 'No Phone'}</p>
              <p><strong>Registration Date:</strong> {userData.created_at ? new Date(userData.created_at).toLocaleDateString() : 'Unknown'}</p>
              <p><strong>Last Login:</strong> {userData.last_login ? new Date(userData.last_login).toLocaleDateString() : 'Never'}</p>
              <p><strong>Grade:</strong> {userData.grade || 'Not specified'}</p>
              <p><strong>Subjects:</strong> {userData.subjects?.join(', ') || 'None'}</p>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="mb-4">No data found for user ID: {params.userId}</p>
              <Link href="/admin/users">
                <Button className="mt-4">
                  Back to Users List
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
} 