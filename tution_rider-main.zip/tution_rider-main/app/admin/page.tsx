'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card"
import Link from "next/link"
import { BookOpen, Users, Settings, MessageSquare } from "lucide-react"

export default function AdminDashboard() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">120</div>
            <p className="text-xs text-muted-foreground">+10% from last month</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Resources</CardTitle>
            <BookOpen className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45</div>
            <p className="text-xs text-muted-foreground">+5 new this week</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">3 unread</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">System</CardTitle>
            <Settings className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Active</div>
            <p className="text-xs text-muted-foreground">All systems normal</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b pb-2">
                <div>John Doe</div>
                <div className="text-sm text-muted-foreground">2 days ago</div>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <div>Jane Smith</div>
                <div className="text-sm text-muted-foreground">3 days ago</div>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <div>Robert Johnson</div>
                <div className="text-sm text-muted-foreground">1 week ago</div>
              </div>
            </div>
            <div className="mt-4 text-center">
              <Link href="/admin/users" className="text-sm text-blue-600 hover:underline">View all users</Link>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Recent Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b pb-2">
                <div>Physics Notes</div>
                <div className="text-sm text-muted-foreground">Added 1 day ago</div>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <div>Chemistry Worksheet</div>
                <div className="text-sm text-muted-foreground">Added 3 days ago</div>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <div>Mathematics Formula Sheet</div>
                <div className="text-sm text-muted-foreground">Added 5 days ago</div>
              </div>
            </div>
            <div className="mt-4 text-center">
              <Link href="/admin/resources" className="text-sm text-blue-600 hover:underline">View all resources</Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
} 