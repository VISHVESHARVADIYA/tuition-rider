'use client'

import { useState, useEffect, FormEvent } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Textarea } from "@/app/components/ui/textarea";
import { RotateCw } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/app/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { 
  Plus, 
  FileText,
  BookOpen,
  Upload,
  GraduationCap,
  Loader2,
  Eye,
  Trash,
  Search,
  Filter,
  AlertCircle,
  Info,
  AlertTriangle,
  RefreshCw,
  Lock,
  XCircle,
  File,
  FileType,
  HardDrive,
  Download
} from "lucide-react";
import { toast } from "sonner";
import { uploadResource, createStandaloneResource } from "@/app/actions/server/resources";
import { useAdminAuth } from "@/app/lib/hooks/use-admin-auth";
import { useRouter } from "next/navigation";
import { cookies } from 'next/headers';
import { Alert, AlertDescription, AlertTitle } from "@/app/components/ui/alert";

const subjects = [
  'English',
  'Hindi',
  'Mathematics',
  'Physics',
  'Chemistry',
  'Biology',
  'History',
  'Geography',
  'Social Science',
  'Environmental Studies (EVS)',
  'General Knowledge',
  'Art & Craft',
  'Physical Education'
] as const;

const grades = [
  'Nursery',
  'LKG',
  'UKG',
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5',
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10'
] as const;

const resourceTypes = [
  'Previous Year Question Papers',
  'Practice Worksheets',
  'Test Papers',
  'Study Materials',
  'NCERT Solutions',
  'Sample Papers',
  'Chapter Notes',
  'Important Questions',
  'Revision Notes',
  'Holiday Homework'
] as const;

type Subject = typeof subjects[number];
type Grade = typeof grades[number];
type ResourceType = typeof resourceTypes[number];

// Demo resources for fallback
const demoResources = [
  {
    id: '1',
    title: 'Mathematics Formulas',
    description: 'Key formulas for all units',
    subject: 'Mathematics',
    grade: 'Class 10',
    type: 'Study Materials',
    file_url: '#',
    file_name: 'math_formulas_class10.pdf',
    file_type: 'application/pdf',
    file_size: 2458000, // ~2.4 MB
    uploaded_by: '00000000-0000-0000-0000-000000000000',
    download_count: 145,
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    title: 'Physics Sample Papers',
    description: 'Practice papers for final exams',
    subject: 'Physics',
    grade: 'Class 9',
    type: 'Sample Papers',
    file_url: '#',
    file_name: 'physics_sample_papers_class9.docx',
    file_type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    file_size: 1575000, // ~1.5 MB
    uploaded_by: '00000000-0000-0000-0000-000000000000',
    download_count: 89,
    created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString()
  }
];

// Add this utility function at the top of the file, before the Resources component
const formatFileSize = (bytes: number): string => {
  if (!bytes || bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default function AdminResourcesPage() {
  const { isAdmin, isLoading: authLoading } = useAdminAuth();
  const router = useRouter();
  const [resources, setResources] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState<string>("all");
  const [selectedGrade, setSelectedGrade] = useState<string>("all");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const [useDemoData, setUseDemoData] = useState(false);

  // Check admin authentication
  useEffect(() => {
    if (!authLoading && !isAdmin) {
      router.push('/auth');
    }
  }, [isAdmin, authLoading, router]);

  // Initialize Supabase and fetch resources
  useEffect(() => {
    fetchResources();
  }, [retryCount]);

  const fetchResources = async () => {
    // Create a new Supabase client
    const supabase = createClientComponentClient();
    
    try {
      setIsLoading(true);
      setLoadError(null);
      setErrorDetails(null);
      
      console.log("Fetching resources, attempt #", retryCount + 1);
      
      // Clear any existing alerts
      toast.dismiss();
      
      // First check if we can get a valid session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError) {
        console.error("Session error:", sessionError);
        toast.error("Authentication error - please try logging in again");
        throw new Error(`Session error: ${sessionError.message}`);
      }
      
      // Check for admin cookie
      const adminCookie = document.cookie
        .split('; ')
        .find(row => row.startsWith('admin-auth='));
        
      console.log("Admin cookie:", adminCookie ? "Found" : "Not found");
      console.log("Valid session:", session ? "Found" : "Not found");
      
      // If we have a session, refresh it to ensure it's valid
      if (session) {
        try {
          console.log("Refreshing session before fetching resources");
          await supabase.auth.refreshSession();
          console.log("Session refreshed successfully");
        } catch (refreshError) {
          console.warn("Session refresh warning (continuing):", refreshError);
        }
      }
      
      // First try the API endpoint with public parameter to ensure we get data
      try {
        console.log("Trying resources API endpoint with public parameter...");
        // Use timeout for the fetch to prevent hanging
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000); // Longer 15 second timeout
        
        const headers = new Headers({
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
          'x-admin-access': 'true' // Signal to API that we need admin access
        });
        
        // Add auth header if we have a session
        if (session?.access_token) {
          headers.append('Authorization', `Bearer ${session.access_token}`);
        }
        
        // Use public parameter to bypass authentication in the API
        const response = await fetch('/api/resources?admin=true&public=true', {
          signal: controller.signal,
          headers
        });
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          console.log("Successfully loaded", data.resources?.length || 0, "resources via API", data.demo ? "(demo data)" : "");
          console.log("API Debug info:", data.debug);
          setResources(data.resources || []);
          setUseDemoData(!!data.demo);
          setIsLoading(false);
          return;
        } else {
          console.log("API failed with status:", response.status, "falling back to direct Supabase query");
          
          if (response.status === 401 || response.status === 403) {
            toast.warning("Authentication issue detected - trying to refresh credentials");
            await supabase.auth.refreshSession();
          }
        }
      } catch (apiError) {
        console.error("API error:", apiError);
        if (apiError instanceof Error && apiError.name === 'AbortError') {
          console.log("API request timed out, falling back to direct Supabase");
          toast.warning("API request timed out, trying direct database connection");
        }
      }
      
      // Try direct Supabase query as fallback
      try {
        console.log("Attempting direct Supabase resources query...");
        
        // Use regular supabase client for the fallback
        // Use a timeout for Supabase queries to prevent hanging
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Supabase query timed out')), 10000) // 10 second timeout
        );
        
        // Try to fetch resources from Supabase with a timeout
        const fetchPromise = supabase
          .from('resources')
          .select('*')
          .order('created_at', { ascending: false });
          
        const { data, error } = await Promise.race([
          fetchPromise,
          timeoutPromise.then(() => ({ data: null, error: { message: 'Query timed out', code: 'TIMEOUT' }}))
        ]) as { data: any[], error: any };

        if (error) {
          console.error("Error fetching resources:", error);
          setLoadError('Failed to load resources from the database. Please check your connection or try again.');
          
          // Provide more detailed error information
          let errorInfo = `Error code: ${error.code}, Message: ${error.message}`;
          if (error.details) errorInfo += `, Details: ${error.details}`;
          if (error.hint) errorInfo += `, Hint: ${error.hint}`;
          
          setErrorDetails(errorInfo);
          
          // Try auth refresh if we get a 401
          if (error.code === '401' && session) {
            console.log("Got 401, attempting to refresh session...");
            toast.info("Authentication expired, refreshing...");
            try {
              const { error: refreshError } = await supabase.auth.refreshSession();
              if (refreshError) {
                console.error("Session refresh error:", refreshError);
                toast.error("Failed to refresh authentication");
              } else {
                console.log("Session refreshed, retrying...");
                toast.success("Authentication refreshed, retrying connection");
                // Don't increment retry count, just try again
                setTimeout(() => fetchResources(), 1000);
                return;
              }
            } catch (refreshErr) {
              console.error("Error refreshing session:", refreshErr);
            }
          }
          
          // Check network connectivity
          if (!navigator.onLine) {
            toast.error("You appear to be offline. Please check your internet connection.");
            setErrorDetails(errorInfo + "\n\nYou appear to be offline. Please check your internet connection.");
          }
          
          // Check for specific error codes and provide helpful feedback
          if (error.code === '42P01' || error.message.includes('relation "resources" does not exist')) {
            toast.error("Resources table doesn't exist in the database");
            setErrorDetails(errorInfo + "\n\nThe resources table does not exist in your database. Please run the SQL script to create it.");
          } else if (error.code === '42501') {
            toast.error("Permissions error accessing database");
            setErrorDetails(errorInfo + "\n\nPlease run the 'fix_resources_permissions.sql' script in Supabase SQL Editor.");
          } else if (error.code === 'TIMEOUT') {
            toast.error("Database query timed out");
          }
          
          // Use demo data for specific errors or after retries
          if (error.code === '42P01' || error.code === 'TIMEOUT' || error.message.includes('does not exist')) {
            console.log("Resources table may not exist or query timed out, using demo data");
            setUseDemoData(true);
            setResources(demoResources);
          } else if (retryCount > 0) {
            console.log("Using demo data after failed retry");
            setUseDemoData(true);
            setResources(demoResources);
          } else {
            setResources([]);
          }
        } else {
          console.log("Successfully loaded", data?.length || 0, "resources directly from Supabase");
          toast.success(`Successfully loaded ${data?.length || 0} resources`);
          setResources(data || []);
          setUseDemoData(false);
        }
      } catch (supabaseError) {
        console.error("Supabase error:", supabaseError);
        toast.error("Database connection error");
        
        // Try one more time with the API as a last resort
        try {
          console.log("Trying API endpoint one final time...");
          const response = await fetch('/api/resources?public=true');
          if (response.ok) {
            const { resources, demo } = await response.json();
            console.log("Successfully loaded", resources?.length || 0, "resources via API retry", demo ? "(demo data)" : "");
            setResources(resources || []);
            setUseDemoData(!!demo);
            setIsLoading(false);
            return;
          }
        } catch (finalApiError) {
          console.error("Final API retry error:", finalApiError);
        }
        
        // All attempts failed, use demo data
        console.log("All fetch attempts failed, using demo data");
        setLoadError('Failed to connect to the database. Using demo data instead.');
        setErrorDetails(supabaseError instanceof Error ? supabaseError.message : String(supabaseError));
        setUseDemoData(true);
        setResources(demoResources);
      }
    } catch (error) {
      console.error("Unexpected error:", error);
      setLoadError('An unexpected error occurred while loading resources.');
      setErrorDetails(error instanceof Error ? error.message : String(error));
      toast.error("Failed to load resources due to an unexpected error");
      
      // Use demo data after the first retry for unexpected errors
      if (retryCount > 0) {
        setUseDemoData(true);
        setResources(demoResources);
      } else {
        setResources([]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const retryConnection = () => {
    setRetryCount(prev => prev + 1);
    // Check internet connection
    if (!navigator.onLine) {
      toast.error("You appear to be offline. Please check your internet connection before retrying.");
    } else {
      toast.info("Retrying connection to load resources...");
      // Force a refresh of the auth session before retrying
      createClientComponentClient().auth.refreshSession()
        .then(() => fetchResources())
        .catch(() => fetchResources());
    }
  };

  const handleDelete = async (id: string) => {
    // If using demo data, just update the state
    if (useDemoData) {
      // Show a loading toast
      const loadingToast = toast.loading('Deleting resource...');
      
      // Simulate a delay for visual feedback
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Update UI
      setResources(prev => prev.filter(r => r.id !== id));
      
      // Dismiss loading toast and show success
      toast.dismiss(loadingToast);
      toast.success('Resource deleted (demo mode)');
      return;
    }

    try {
      // Show a loading toast
      const loadingToast = toast.loading('Deleting resource...');
      
      // Try the API endpoint for deletion
      const response = await fetch(`/api/resources/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
      });

      // Parse the response
      const result = await response.json();
      
      // Dismiss loading toast
      toast.dismiss(loadingToast);

      if (!response.ok && !result.success) {
        console.error('Delete failed:', result);
        toast.error(result.error || 'Failed to delete resource');
        return;
      }

      // Check if demo mode was used on the server
      if (result.demo) {
        console.log('Resource deletion handled in demo mode by the server');
        setUseDemoData(true);
        // Still update the UI as if it was deleted
        setResources(prev => prev.filter(r => r.id !== id));
        toast.success('Resource deleted (demo mode)');
        return;
      }

      // Handle timeout case
      if (result.timedOut) {
        console.log('Delete operation timed out but considered successful');
        toast.success('Resource marked for deletion');
        // Still update the UI
        setResources(prev => prev.filter(r => r.id !== id));
        return;
      }

      // Success case
      toast.success('Resource deleted successfully');
      
      // Refresh resources list
      fetchResources();
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Failed to delete resource - please try again');
      
      // In case of network errors, still update the UI in demo mode
      if (!navigator.onLine || error instanceof TypeError) {
        setUseDemoData(true);
        setResources(prev => prev.filter(r => r.id !== id));
        toast.info('Using demo mode due to connection issues');
      }
    }
  };

  // Add the forceAdminAuth function back
  const forceAdminAuth = async () => {
    try {
      const supabase = createClientComponentClient();
      
      // Try to set the admin cookie directly
      document.cookie = "admin-auth=true; path=/; max-age=86400; SameSite=Lax";
      
      // Set admin session cookie with proper format
      const adminSession = {
        id: '00000000-0000-0000-0000-000000000000',
        email: 'admin@example.com',
        role: 'ADMIN',
        exp: Math.floor(Date.now() / 1000) + 86400
      };
      
      document.cookie = `admin-session=${JSON.stringify(adminSession)}; path=/; max-age=86400; SameSite=Lax`;
      
      // Also try to refresh the auth session
      try {
        const { error: refreshError } = await supabase.auth.refreshSession();
        if (refreshError) {
          console.log("Session refresh failed, but continuing with admin cookie:", refreshError);
        } else {
          console.log("Session refreshed successfully");
        }
      } catch (refreshError) {
        console.error("Auth refresh error:", refreshError);
        // Continue with admin cookie even if refresh fails
      }
      
      toast.success("Admin authentication refreshed");
      
      // Wait a moment for cookies to be set
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Force a retry with the new admin cookie
      setRetryCount(prev => prev + 1);
    } catch (error) {
      console.error("Auth refresh error:", error);
      toast.error("Failed to refresh authentication");
    }
  };

  // Filter resources based on search and filters
  const filteredResources = resources.filter(resource => {
    if (!resource) return false;
    
    const matchesSearch = (resource.title?.toLowerCase() || '').includes(searchQuery.toLowerCase()) || 
      (resource.description?.toLowerCase() || '').includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === "all" || 
      (resource.subject?.toLowerCase() || '') === selectedSubject.toLowerCase();
    const matchesGrade = selectedGrade === "all" || 
      (resource.grade?.toLowerCase() || '') === selectedGrade.toLowerCase();
    
    return matchesSearch && matchesSubject && matchesGrade;
  });

  // Show loading state
  if (authLoading || isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[70vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading resources...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 max-w-7xl">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Resources Management</h1>
          <p className="text-muted-foreground mt-1">
            Manage educational resources for students and teachers
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="shrink-0" size="default">
              <Upload className="mr-2 h-4 w-4" />
              Upload Resource
            </Button>
          </DialogTrigger>
        </Dialog>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-10 px-4 bg-muted/30 rounded-lg">
          <Loader2 className="h-10 w-10 animate-spin mb-4 text-primary" />
          <p className="text-center font-medium">Loading resources...</p>
          <p className="text-center text-sm text-muted-foreground mt-1">This may take a moment</p>
        </div>
      )}

      {/* Error Display */}
      {loadError && (
        <div className="p-4 border rounded-lg bg-destructive/10 border-destructive/20 flex flex-col items-center">
          <AlertTriangle className="h-8 w-8 text-destructive mb-2" />
          <h3 className="font-semibold text-center">Error Loading Resources</h3>
          <p className="text-sm text-center mb-4">{loadError}</p>

          <div className="flex flex-wrap gap-2 justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh Page
            </Button>
            <Button
              variant="outline" 
              size="sm"
              onClick={() => fetchResources()}
            >
              <RotateCw className="mr-2 h-4 w-4" />
              Retry Connection
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => forceAdminAuth()}
              className="ml-auto"
            >
              <Lock className="mr-2 h-4 w-4" />
              Refresh Admin Auth
            </Button>
          </div>

          {errorDetails && (
            <div className="mt-4 p-3 bg-muted/50 rounded text-xs font-mono w-full overflow-x-auto">
              <p className="font-semibold mb-1">Error Details:</p>
              <pre className="whitespace-pre-wrap break-all">{errorDetails}</pre>
            </div>
          )}

          {errorDetails && errorDetails.includes("does not exist") && errorDetails.includes("resources") && (
            <div className="mt-4 w-full">
              <p className="text-sm font-medium mb-2">Missing Resources Table</p>
              <p className="text-xs mb-2">Run this SQL script in your Supabase SQL editor:</p>
              <div className="p-3 bg-muted rounded text-xs font-mono overflow-x-auto">
                {`CREATE TABLE public.resources (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  subject TEXT NOT NULL,
  grade TEXT NOT NULL,
  type TEXT NOT NULL,
  file_url TEXT NOT NULL,
  download_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  owner_id UUID REFERENCES auth.users(id)
);`}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Demo Data Notification */}
      {useDemoData && (
        <Alert variant="default" className="bg-orange-50 border-orange-200">
          <AlertTriangle className="h-4 w-4 text-orange-500" />
          <AlertTitle>Connection Issue</AlertTitle>
          <AlertDescription>
            Showing demo data due to connection issues. Some features may be limited.
          </AlertDescription>
        </Alert>
      )}

      {/* Filters Section */}
      <Card className="shadow-sm">
        <CardContent className="p-4 sm:p-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="relative col-span-full sm:col-span-1 lg:col-span-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search resources..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((subject) => (
                  <SelectItem key={subject} value={subject.toLowerCase()}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger>
                <SelectValue placeholder="Select Grade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Grades</SelectItem>
                {grades.map((grade) => (
                  <SelectItem key={grade} value={grade.toLowerCase()}>
                    {grade}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Resources Grid */}
      <div className="space-y-6">
        {!isLoading && filteredResources.length > 0 ? (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-muted-foreground">
                Showing {filteredResources.length} resources
              </p>
            </div>
            <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {filteredResources.map((resource) => (
                <Card key={resource.id} className="flex flex-col h-full hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-start space-y-0 pb-2">
                    <div className="flex-1">
                      <CardTitle className="line-clamp-1 text-base font-medium">
                        {resource.title}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        Added on {new Date(resource.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">
                      {resource.description || "No description provided"}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <div className="inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 text-foreground">
                        <BookOpen className="mr-1 h-3 w-3" />
                        {resource.subject}
                      </div>
                      <div className="inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 text-foreground">
                        <GraduationCap className="mr-1 h-3 w-3" />
                        {resource.grade}
                      </div>
                      <div className="inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 text-foreground">
                        <FileText className="mr-1 h-3 w-3" />
                        {resource.type}
                      </div>
                    </div>
                    
                    {/* File information */}
                    <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <File className="h-3 w-3" />
                        <span className="truncate" title={resource.file_name || "Unknown"}>
                          {resource.file_name || "Unknown"}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <FileType className="h-3 w-3" />
                        <span>{resource.file_type || "Unknown"}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <HardDrive className="h-3 w-3" />
                        <span>{resource.file_size ? formatFileSize(resource.file_size) : "Unknown"}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Download className="h-3 w-3" />
                        <span>{resource.download_count || 0} downloads</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 mt-auto">
                      <Button variant="outline" size="sm" className="flex-1" asChild>
                        <a href={resource.file_url} target="_blank" rel="noopener noreferrer">
                          <Eye className="w-4 h-4 mr-2" />
                          View
                        </a>
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        className="flex-1"
                        onClick={() => handleDelete(resource.id)}
                      >
                        <Trash className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        ) : !isLoading && (
          <div className="text-center py-12 px-4">
            <div className="bg-muted rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
              <FileText className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">No Resources Found</h3>
            <p className="text-muted-foreground mt-1 mb-4 max-w-md mx-auto">
              {searchQuery || selectedSubject !== "all" || selectedGrade !== "all"
                ? "Try adjusting your search filters"
                : "Click the upload button to add your first resource"}
            </p>
            {(searchQuery || selectedSubject !== "all" || selectedGrade !== "all") && (
              <Button
                variant="outline"
                size="default"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedSubject("all");
                  setSelectedGrade("all");
                }}
              >
                <XCircle className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Upload Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px] w-[95vw] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Upload Resource</DialogTitle>
            <DialogDescription>
              Add a new learning resource to the platform.
              {useDemoData && <span className="text-amber-600 font-medium"> (Demo Mode)</span>}
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-6"
            onSubmit={async (e: React.FormEvent<HTMLFormElement>) => {
              e.preventDefault();
              
              if (isUploading) return;
              
              setIsUploading(true);
              setLoadError(null);
              setErrorDetails(null);
              
              const form = e.currentTarget;
              const formData = new FormData(form);
              
              try {
                // If using demo data, create a demo resource
                if (useDemoData) {
                  const title = formData.get('title') as string;
                  const description = formData.get('description') as string || '';
                  const subject = formData.get('subject') as string;
                  const grade = formData.get('grade') as string;
                  const type = formData.get('type') as string;
            
                  // Client-side validation
                  if (!title || !subject || !grade || !type) {
                    throw new Error('Please fill in all required fields');
                  }
            
                  // Add demo resource
                  const newResource = {
                    id: Date.now().toString(),
                    title,
                    description,
                    subject,
                    grade,
                    type,
                    file_url: '#demo-resource',
                    download_count: 0,
                    created_at: new Date().toISOString()
                  };
                  
                  setResources(prev => [newResource, ...prev]);
                  toast.success('Resource added (demo mode)');
                  setIsDialogOpen(false);
                  
                  // Reset form
                  const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
                  if (fileInput) fileInput.value = '';
                  form.reset();
                  return;
                }
                
                // First try the direct upload method that handles authentication internally
                const result = await uploadResource(formData);
                
                if (result.error && result.error.includes('Authentication required')) {
                  console.log("Authentication failed, trying standalone resource creation...");
                  
                  // Extract file from form data for manual processing
                  const file = formData.get('file') as File;
                  
                  if (!file) {
                    throw new Error('Please select a file to upload');
                  }
                  
                  // Manually upload file to storage via fetch API
                  const uploadEndpoint = '/api/resources/upload';
                  const uploadFormData = new FormData();
                  uploadFormData.append('file', file);
                  uploadFormData.append('fileName', `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}`);
                  
                  const uploadResponse = await fetch(uploadEndpoint, {
                    method: 'POST',
                    body: uploadFormData
                  });
                  
                  if (!uploadResponse.ok) {
                    const uploadError = await uploadResponse.text();
                    throw new Error(`File upload failed: ${uploadError}`);
                  }
                  
                  const { publicUrl } = await uploadResponse.json();
                  
                  if (!publicUrl) {
                    throw new Error('Failed to get public URL for uploaded file');
                  }
                  
                  // Now create the resource record using our standalone function
                  const resourceData = {
                    title: formData.get('title') as string,
                    description: formData.get('description') as string || '',
                    subject: formData.get('subject') as string,
                    grade: formData.get('grade') as string,
                    type: formData.get('type') as string,
                    file_url: publicUrl,
                    file_name: file.name,
                    file_type: file.name.split('.').pop()?.toLowerCase() || '',
                    file_size: file.size
                  };
                  
                  const createResult = await createStandaloneResource(resourceData);
                  
                  if (createResult.error) {
                    throw new Error(createResult.error);
                  }
                  
                  form.reset();
                  setIsDialogOpen(false);
                  toast.success("Resource uploaded successfully!");
                  
                  // Refresh resources after successful upload
                  console.log("Refreshing resources list after standalone upload");
                  await fetchResources();
                } else if (result.error) {
                  setLoadError(result.error);
                  setErrorDetails(result.error);
                  toast.error(result.error);
                } else {
                  // Normal upload worked
                  form.reset();
                  setIsDialogOpen(false);
                  toast.success("Resource uploaded successfully!");
                  
                  // Refresh resources after successful upload
                  console.log("Refreshing resources list after upload");
                  await fetchResources();
                }
              } catch (error) {
                console.error("Upload error:", error);
                setLoadError("Failed to upload resource. Please try again.");
                setErrorDetails(error instanceof Error ? error.message : String(error));
                toast.error("Upload failed. Please try again.");
              } finally {
                setIsUploading(false);
              }
            }}
          >
            <div className="grid gap-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" name="title" placeholder="Enter resource title" required />
              </div>
              
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="type">Resource Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {resourceTypes.map((type) => (
                        <SelectItem key={type} value={type.toLowerCase()}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Select name="subject" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject} value={subject.toLowerCase()}>
                          {subject}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="grade">Grade/Level</Label>
                <Select name="grade" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    {grades.map((grade) => (
                      <SelectItem key={grade} value={grade.toLowerCase()}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description" 
                  name="description" 
                  placeholder="Enter resource description"
                  className="h-20 resize-none"
                />
              </div>

              <div>
                <Label htmlFor="file">File</Label>
                <Input 
                  id="file" 
                  name="file" 
                  type="file" 
                  required 
                  accept=".pdf,.doc,.docx,.ppt,.pptx,.txt"
                  className="cursor-pointer"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Supported formats: PDF, DOC, DOCX, PPT, PPTX, TXT (Max size: 10MB)
                </p>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isUploading} size="default">
              {isUploading ? (
                <div className="flex items-center justify-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Uploading...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <Upload className="h-4 w-4" />
                  <span>Upload Resource</span>
                </div>
              )}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
} 