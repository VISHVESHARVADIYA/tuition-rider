'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { getCookie, setCookie, deleteCookie } from 'cookies-next';
import { env } from '@/env.mjs';

export function useAdminAuth() {
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isLoggingOut, setIsLoggingOut] = useState<boolean>(false);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const checkAdminAuth = () => {
      const adminAuth = getCookie('admin-auth');
      console.log('Admin auth cookie:', adminAuth);

      if (adminAuth === 'true') {
        console.log('Admin authenticated successfully');
        setIsAdmin(true);
        // Refresh the cookie to extend its lifetime
        setCookie('admin-auth', 'true', {
          maxAge: 60 * 60 * 24 * 7, // 1 week
          path: '/',
          // Make sure these match the settings in the API
          httpOnly: false,
          secure: env.NODE_ENV === 'production',
          sameSite: 'lax',
        });
      } else if (pathname?.startsWith('/admin') && !pathname.includes('/login')) {
        console.log('Not authenticated, redirecting to login');
        // Redirect to admin login page if not authenticated and accessing admin routes
        router.push('/admin/login');
      }

      setIsLoading(false);
    };

    checkAdminAuth();
    
    // Set up cookie refresh interval
    const interval = setInterval(() => {
      const adminAuth = getCookie('admin-auth');
      if (adminAuth === 'true') {
        setCookie('admin-auth', 'true', {
          maxAge: 60 * 60 * 24 * 7, // 1 week
          path: '/',
          // Make sure these match the settings in the API
          httpOnly: false,
          secure: env.NODE_ENV === 'production',
          sameSite: 'lax',
        });
      }
    }, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [pathname, router]);

  const logout = async () => {
    try {
      setIsLoggingOut(true);
      console.log('Logging out admin user');

      // Clear all admin-related cookies
      setCookie('admin-auth', '', { maxAge: -1, path: '/' });
      setCookie('admin-session', '', { maxAge: -1, path: '/' });
      setCookie('auth-token', '', { maxAge: -1, path: '/' });
      setCookie('user-role', '', { maxAge: -1, path: '/' });

      setIsAdmin(false);

      // Add a small delay to ensure UI shows loading state
      await new Promise(resolve => setTimeout(resolve, 500));

      // Redirect to home page instead of auth
      router.push('/');
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      // Reset loading state after a short delay to ensure the UI transition is smooth
      setTimeout(() => {
        setIsLoggingOut(false);
      }, 300);
    }
  };

  const handleLogout = useCallback(async () => {
    try {
      deleteCookie('admin-auth', {
        secure: env.NODE_ENV === 'production',
      });
      // ... existing code ...
    } catch (error) {
      // ... existing code ...
    }
  }, [router]);

  const setAdminCookie = useCallback((token: string) => {
    setCookie('admin-auth', token, {
      secure: env.NODE_ENV === 'production',
      // ... existing code ...
    });
  }, []);

  return { isAdmin, isLoading, isLoggingOut, logout };
} 