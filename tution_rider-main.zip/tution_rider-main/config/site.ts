import { NavItem } from "@/types";
import { env } from "@/env.mjs";

const site_url = env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

export const siteConfig = {
  name: "TuitionRider",
  description: "Your trusted platform for offline tutoring",
  url: site_url,
  ogImage: `${site_url}/_static/og.jpg`,
  email: "tuitionrider1@gmail.com",
  links: {
    twitter: "https://twitter.com/tuitionrider",
    github: "https://github.com/Raahul-01",
    linkedin: "https://www.linkedin.com/company/tuition-rider/",
    facebook: "https://www.facebook.com/Schoolstudyhometuition",
    instagram: "https://www.instagram.com/tuitionrider?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
  },
  mailSupport: "tuitionrider1@gmail.com",
};

type FooterSection = {
  title: string;
  items: {
    title: string;
    href: string;
  }[];
};

export const footerLinks: FooterSection[] = [
  {
    title: "Company",
    items: [
      { title: "About Us", href: "/about" },
      { title: "Our Services", href: "/services" },
      { title: "Contact", href: "/contact" },
    ],
  },
  {
    title: "Resources",
    items: [
      { title: "Blog", href: "/blog" },
      { title: "FAQ", href: "/faq" },
      { title: "Privacy Policy", href: "/privacy" },
    ],
  },
];
