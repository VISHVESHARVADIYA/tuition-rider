"use server";

import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth-options';
import { db } from "@/lib/db";
import { userNameSchema } from "@/lib/validations/user";
import { revalidatePath } from "next/cache";
import { z } from "zod";

type SessionUser = {
  id: string;
  name?: string | null;
  email?: string | null;
  image?: string | null;
}

export async function updateUsername(
  userId: string,
  data: z.infer<typeof userNameSchema>
) {
  try {
    // Get the current session
    const session = await getServerSession(authOptions);
    
    // Check if the user is authenticated
    if (!session) {
      return { error: "Unauthorized" };
    }
    
    if (!session?.user) {
      return { error: "Unauthorized" };
    }
    
    // Check if the user is updating their own name
    if ((session.user as SessionUser).id !== userId) {
      return { error: "Unauthorized" };
    }

    // Validate input
    const { name } = userNameSchema.parse(data);

    // Update user name
    await db.user.update({
      where: { id: userId },
      data: { name },
    });

    revalidatePath("/dashboard");
    revalidatePath("/settings");

    return { success: "Username updated" };
  } catch (error: unknown) {
    if (error instanceof z.ZodError) {
      return { error: error.errors[0].message };
    }
    
    return { error: "Something went wrong" };
  }
}