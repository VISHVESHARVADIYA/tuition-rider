"use server";

import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth-options";
import { UserRole } from "@prisma/client";
import { db } from "@/lib/db";
import { userRoleSchema } from "@/lib/validations/user";
import { revalidatePath } from "next/cache";

export async function updateUserRole(userId: string, data: { role: UserRole }) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return { status: "error", message: "Unauthorized" };
    }

    const validatedFields = userRoleSchema.safeParse(data);

    if (!validatedFields.success) {
      return { status: "error", message: "Invalid fields." };
    }

    const { role } = validatedFields.data;

    // Update the user role.
    await db.user.update({
      where: {
        id: userId,
      },
      data: {
        role,
      },
    });

    revalidatePath("/dashboard/users");
    return { status: "success" };
  } catch (error) {
    return { status: "error", message: "Failed to update user role." };
  }
}
